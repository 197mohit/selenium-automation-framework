profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
WORKSPACE=$2
backupPath=/paytm/BuildBckup 
echo "value of"$1
if [ $1 = automation ]
then
    	sshServer=dev@10.144.18.120
	scp -r $WORKSPACE/conf/pg_auto/project  $sshServer:/paytm/NewBuild/
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.185
	cd $WORKSPACE
	cd ..
	scp -r Build-Resources/pgp_$profileName/project $sshServer:/paytm/NewBuild/
elif [ $1 = integration ]
then
   	profileName=automation
   	sshServer=pgtest@10.142.51.190
	scp -r $WORKSPACE/conf/pg_auto/project  $sshServer:/paytm/NewBuild/
elif [ $1 = qa4 ]
then
	sshServer=pgtest@10.
	scp -r /paytm/conf/pgp_$profileName/cron_jobs/project/ $sshServer:/paytm/NewBuild/
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.
	scp -r /paytm/conf/pgp_$profileName/cron_jobs/project/ $sshServer:/paytm/NewBuild/
else
    echo Incorrect profile
fi
echo $sshServer

cd $WORKSPACE;
mvn clean install  -DskipTests -P$profileName -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit;
fi

scp -r  $WORKSPACE/scheduler/target/scheduler $sshServer:/paytm/NewBuild/

ssh -T  $sshServer  "ps aux | grep 'looper'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/scheduler  $backupPath/scheduler_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer mv  /paytm/NewBuild/scheduler /paytm/
if [ $? -eq 0 ]; then
    echo "folder copy to  paytm success"
else
    echo "folder copy to paytm  fail"
fi
ssh -T $sshServer  mv  /etc/appconf/project /etc/appconf/project_bckup
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updated successfully"
fi
#nohup ssh -T $sshServer sh /paytm/looper-service/bin/startserver.sh &
echo "scheduler build has been copied to the server, please deploy the cron jobs manually "
