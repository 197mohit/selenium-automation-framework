profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/mapping-service/apache-tomcat
WORKSPACE=$2
backupPath=/paytm/BuildBckup
echo "tomcat: " $tomcatPath

cd $WORKSPACE/..
if [ $1 = automation ]
then
   sshServer=dev@10.144.18.103
   profileName=auto
elif [ $1 = hotfix ]
then
   profileName=hotfix
   sshServer=pgtest@10.142.51.102
elif [ $1 = staging ]
then
   profileName=staging
   sshServer=pgtest@10.142.51.142
elif [ $1 = qa4 ]
then
   profileName=qa4
   sshServer=pgtest@10.142.51.205
elif [ $1 = qa5 ]
then
   profileName=qa5
   sshServer=pgtest@10.142.51.212
else
   echo Incorrect profile
   exit 1
fi
echo "copying resources to server"
scp -r Build-Resources/pgp_$profileName/mapping-service/project $sshServer:/paytm/NewBuild/

cd $WORKSPACE;
mvn clean install  -DskipTests -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi

scp $WORKSPACE/mapping-service/target/mapping-service.war $sshServer:/paytm/NewBuild/
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/mapping-service  $backupPath/mapping-service_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/mapping-service.war $tomcatPath/webapps/mapping-service.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh                                                                                                                                                  
