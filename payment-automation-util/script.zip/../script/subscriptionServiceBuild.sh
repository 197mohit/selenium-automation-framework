CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/subscription/apache-tomcat
backupPath=/paytm/BuildBckup
profileName=$1

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
      	sshServer=dev@10.144.18.111
elif [ $1 = hotfix ]
then
 	sshServer=pgtest@10.142.51.99
elif [ $1 = staging ]
then
     	sshServer=pgtest@10.142.51.157
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.51.200
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.173
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/subscription/project $sshServer:/paytm/NewBuild/
echo $sshServer

cd $WORKSPACE;
mvn clean install  -DskipTests  -e
if [ $? -eq 0 ]; then
    echo "Build Success"
else
    echo "Build Fail"
    exit 1;
fi

scp $WORKSPACE/subscription/target/subscription.war $sshServer:/paytm/NewBuild/

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/subscription  $backupPath/subscription_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/subscription.war $tomcatPath/webapps/subscription.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
