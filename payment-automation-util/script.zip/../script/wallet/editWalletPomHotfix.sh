#!/bin/bash
cd /paytm/jenkins_home/workspace/Wallet-Web/paytm-wallet/wallet-common/;
sed -i -e 's/10.0.3.14/accounts-staging.paytm.in/g' pom.xml;
sed -i 's/<alipay.signature.toggle>1/<alipay.signature.toggle>0/g' pom.xml;
sed -i -e 's/<wallet.web.service_base_url>http:\/\/10.0.3.245:18080i\/wallet-web<\/wallet.web.service_base_url>/<wallet.web.service_base_url>http:\/\/10.142.51.92:18080\/wallet-web<\/wallet.web.service_base_url>/' pom.xml

sed -i -e 's/<wallet.web.soap.service_base_url>http:\/\/10.0.3.245:18080\/wallet-web<\/wallet.web.soap.service_base_url>/<wallet.web.soap.service_base_url>http:\/\/10.142.51.92:18080\/wallet-web<\/wallet.web.soap.service_base_url>/' pom.xml

sed -i -e 's/kyc-staging.paytm.com/accounts-staging.paytm.in/g' pom.xml;

sed -i -e 's/<redis.serverHost>localhost<\/redis.serverHost>/<redis.serverHost>10.142.51.92<\/redis.serverHost>/' pom.xml

sed -i -e 's/<balances.redis.serverHost>localhost<\/balances.redis.serverHost>/<balances.redis.serverHost>10.142.51.92<\/balances.redis.serverHost>/' pom.xml

sed -i -e 's/<qr.code.redis.serverHost>localhost<\/qr.code.redis.serverHost>/<qr.code.redis.serverHost>10.142.51.92<\/qr.code.redis.serverHost>/' pom.xml

sed -i -e 's/<walletAdmin.origin.url>http:\/\/10.0.3.119:9999<\/walletAdmin.origin.url>/<walletAdmin.origin.url>http:\/\/10.142.0.112:18080<\/walletAdmin.origin.url>/' pom.xml

sed -i -e 's/<kafka.zookepers>10.0.3.244:2181<\/kafka.zookepers>/<kafka.zookepers>10.142.51.92:2181<\/kafka.zookepers>/' pom.xml

sed -i -e 's/<kafka.brokers>10.0.3.244:9092<\/kafka.brokers>/<kafka.brokers>10.142.51.92:9092<\/kafka.brokers>/' pom.xml

sed -i -e 's/<kafka.dwh.brokers>localhost:9092<\/kafka.dwh.brokers>/<kafka.dwh.brokers>10.142.51.92:9092<\/kafka.dwh.brokers>/' pom.xml

sed -i -e 's/<aerospike.ip>127.0.0.1<\/aerospike.ip>/<aerospike.ip>10.142.51.120<\/aerospike.ip>/' pom.xml

sed -i -e 's/<pg.refund.service.refund.url>https:\/\/pgp-sandbox.paytm.in/<pg.refund.service.refund.url>https:\/\/pgp-hotfix.paytm.in/' pom.xml

sed -i -e 's/<p2p.ftu.redis.serverHost>localhost<\/p2p.ftu.redis.serverHost>/<p2p.ftu.redis.serverHost>10.142.51.92<\/p2p.ftu.redis.serverHost>/' pom.xml

sed -i -e 's/<redis.sentinel.enable>1<\/redis.sentinel.enable>/<redis.sentinel.enable>0<\/redis.sentinel.enable>/' pom.xml

sed -i -e 's/<merchant.base.url>http:\/\/10.0.3.119:7777\/wallet-merchant<\/merchant.base.url>/<merchant.base.url>http:\/\/10.142.51.92:18080\/wallet-merchant<\/merchant.base.url>/' pom.xml

sed -i -e 's/<walletAdmin.base.url>http:\/\/10.0.3.119:9999\/wallet-admin<\/walletAdmin.base.url>/<walletAdmin.base.url>http:\/\/10.142.0.112:18080\/wallet-admin<\/walletAdmin.base.url>/' pom.xml

sed -i -e 's/<walletAdmin.origin.url>http:\/\/10.0.3.119:9999\/wallet-admin<\/walletAdmin.origin.url>/<walletAdmin.origin.url>http:\/\/10.142.0.112:18080\/wallet-admin<\/walletAdmin.origin.url>/' pom.xml

sed -i -e 's/<mapping.service.url>http:\/\/52.76.10.37<\/mapping.service.url>/<mapping.service.url>https:\/\/pgp-hotfix.paytm.in<\/mapping.service.url>/' pom.xml

sed -i -e 's/<ump.base.url>https:\/\/staging-dashboard.paytm.com<\/ump.base.url>/<ump.base.url>http:\/\/10.142.0.81<\/ump.base.url>/' pom.xml


