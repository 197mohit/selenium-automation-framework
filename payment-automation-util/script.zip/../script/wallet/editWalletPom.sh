#!/bin/bash
cd /home/suresh_18193/.jenkins/workspace/Wallet-Web/paytm-wallet/wallet-common/;
sed -i -e 's/10.0.3.14/accounts-staging.paytm.in/g' pom.xml;
sed -i -e 's/kyc-staging.paytm.com/accounts-staging.paytm.in/g' pom.xml;
sed -i -e 's/<redis.serverHost>localhost<\/redis.serverHost>/<redis.serverHost>10.144.18.114<\/redis.serverHost>/' pom.xml
sed -i -e 's/<balances.redis.serverHost>localhost<\/balances.redis.serverHost>/<balances.redis.serverHost>10.144.18.114<\/balances.redis.serverHost>/' pom.xml
sed -i -e 's/<qr.code.redis.serverHost>localhost<\/qr.code.redis.serverHost>/<qr.code.redis.serverHost>10.144.18.114<\/qr.code.redis.serverHost>/' pom.xml

sed -i -e 's/<p2p.ftu.redis.serverHost>localhost<\/p2p.ftu.redis.serverHost>/<p2p.ftu.redis.serverHost>10.144.18.114<\/p2p.ftu.redis.serverHost>/' pom.xml

sed -i -e 's/<redis.sentinel.enable>1<\/redis.sentinel.enable>/<redis.sentinel.enable>0<\/redis.sentinel.enable>/' pom.xml

sed -i -e 's/<merchant.base.url>http:\/\/10.0.3.119:7777\/wallet-merchant<\/merchant.base.url>/<merchant.base.url>http:\/\/10.144.18.113:18081\/wallet-merchant<\/merchant.base.url>/' pom.xml

sed -i -e 's/<walletAdmin.base.url>http:\/\/10.0.3.119:9999\/wallet-admin<\/walletAdmin.base.url>/<walletAdmin.base.url>http:\/\/10.142.0.112:18080\/wallet-admin<\/walletAdmin.base.url>/' pom.xml

sed -i -e 's/<walletAdmin.origin.url>http:\/\/10.0.3.119:9999\/wallet-admin<\/walletAdmin.origin.url>/<walletAdmin.origin.url>http:\/\/10.142.0.112:18080\/wallet-admin<\/walletAdmin.origin.url>/' pom.xml

sed -i -e 's/<mapping.service.url>http:\/\/52.76.10.37<\/mapping.service.url>/<mapping.service.url>http:\/\/10.144.18.103:8080<\/mapping.service.url>/' pom.xml

sed -i -e 's/<ump.base.url>https:\/\/staging-dashboard.paytm.com<\/ump.base.url>/<ump.base.url>http:\/\/10.142.0.81<\/ump.base.url>/' pom.xml


