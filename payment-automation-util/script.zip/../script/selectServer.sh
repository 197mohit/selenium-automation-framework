if [ $Profile == "pgp-automation"] then
    server = dev@$2
elif [ $Profile == hotfix ] then
	server = pgtest@$3
else
	echo invalid profile
if
scp -r $WORKSPACE/conf/instaproxy/pgp-automation/project $server:/paytm/NewBuild/
scp $WORKSPACE/instaproxy/target/instaproxy.war $server:/paytm/NewBuild/
