profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/promoService/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
	sshServer=dev@10.144.18.108
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.106
elif [ $1 = staging ]
then
        sshServer=pgtest@10.142.51.150
elif [ $1 = qa4 ]
then 
	sshServer=pgtest@10.142.51.222
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.221
else
    	echo Incorrect profile
    	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/promo-service/project $sshServer:/paytm/NewBuild/

cd $WORKSPACE;
mvn clean install  -DskipTests -P$1 -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi

scp $WORKSPACE/promo-service/target/promo-service.war $sshServer:/paytm/NewBuild/

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/promo-service  $backupPath/promo-service_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/promo-service.war  $tomcatPath/webapps/promo-service.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer rm -rf /etc/appconf/project_bckup/project
ssh -T $sshServer mv /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi

ssh -T $sshServer sh $tomcatPath/bin/startup.sh

