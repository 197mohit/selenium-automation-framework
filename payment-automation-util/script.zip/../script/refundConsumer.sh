#!/bin/bash
. ./commonFunctions.sh

profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
    	sshServer=dev@10.144.18.112
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.121
elif [ $1 = staging ]
then
        sshServer=pgtest@10.144.18.116
elif [ $1 = qa4 ]
then
	sshServer=pgtest@
elif [ $1 = qa5 ]
then
	sshServer=pgtest@
else
    	echo Incorrect profile
	exit 1
fi

scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/refund-consumer/project $sshServer:/paytm/NewBuild/
validateStep "scp resources"

cd $WORKSPACE; mvn clean install  -DskipTests -P$1 -e
validateStep "build project"

scp -r  $WORKSPACE/refund-consumer/target/refund-consumer $sshServer:/paytm/NewBuild/
validateStep "scp project"

ssh -T  $sshServer  "ps aux | grep 'looper'| grep -v grep|awk '{print \$2}' | xargs kill -9"

ssh -T  $sshServer mv /paytm/refund-consumer  $backupPath/refund-consumer_$CurrentTime
validateStep "backup project"

ssh -T $sshServer mv  /paytm/NewBuild/refund-consumer /paytm/
validateStep "folder copy to paytm"

ssh -T $sshServer mv  /etc/appconf/project /etc/appconf/project_bckup

ssh -T $sshServer mv  /paytm/NewBuild/project /etc/appconf/
validateStep "copy updated project properties"

nohup ssh -T $sshServer sh /paytm/refund-consumer/bin/startserver.sh &
