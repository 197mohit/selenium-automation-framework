ProfileName =$1
echo $1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup
if [ $1 = automation ]
then
    sshServer=dev@10.144.18.119
    confName=pgp_auto
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.209
   confName=pgp-hotfix
elif [ $1 = staging ]
then
   sshServer=pgtest@10.142.51.142
   confName=pgp-staging
elif [ $1 = qa4 ]
then
   sshServer=pgtest@10.142.51.205
   confName=pgp-qa4
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.51.212
   confName=pgp-qa5
else
    echo Incorrect profile
fi
echo $sshServer
WORKSPACE=$2
cd $WORKSPACE;
mvn clean install  -DskipTests -P$1 -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit;
fi
scp -r $WORKSPACE/conf/mapping_service/$confName/project $sshServer:/paytm/NewBuild/
scp -r $WORKSPACE/mapping-service-integration/target/mapping-service-integration $sshServer:/paytm/NewBuild/

echo $sshServer
ssh -T  $sshServer  "ps aux | grep 'MappingServiceIntegration'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer cp -r /paytm/mapping-service-integration  $backupPath/mapping-service-integration_$CurrentTime
if [ $? -eq 0 ]; then
    echo "backup done"
else
    echo "backup fail"
fi
ssh -T $sshServer cp -r  /paytm/NewBuild/mapping-service-integration /paytm/
if [ $? -eq 0 ]; then
    echo "folder copy to  paytm success"
else
    echo "folder copy to paytm  fail"
fi
ssh -T $sshServer cp -r /etc/appconf/project /etc/appconf/project_old
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/project
if [ $? -eq 0 ]; then
    echo "appconf project folder copy success"
else
    echo "appconf project folder copy  fail"
fi

#ssh -T $sshServer ps -ef | grep java
#nohup ssh -T $sshServer sh /paytm/mapping-service-integration/bin/startserver.sh &
#echo "mapping integration started "
#sleep 20
#ssh -T $sshServer  "ps aux | grep 'MappingServiceIntegration'| grep -v grep|awk '{print \$2}' | xargs kill -9"
#ssh -T $sshServer cp -r /propertyBck/resources/* /paytm/mapping-service-integration/resources/
#if [ $? -eq 0 ]; then
#    echo "property backup  success"
#else     
#    echo "property backup   fail"
#fi

nohup ssh -T $sshServer sh /paytm/mapping-service-integration/bin/startserver.sh &

