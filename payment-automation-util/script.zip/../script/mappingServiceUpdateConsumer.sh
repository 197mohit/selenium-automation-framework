#!/bin/bash
. ./commonFunctions.sh

profile=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profile
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
    	sshServer=dev@10.144.18.119
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.209
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.158
elif [ $1 = qa4 ]
then 
	sshServer=pgtest@10.142.52.29
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.52.35
else
    	echo Incorrect profile
	exit 1
fi

cd $WORKSPACE; mvn clean install  -DskipTests -e
validateStep "build project"

scp -r $WORKSPACE/../Build-Resources/pgp_$profile/mapping-service-update-consumer/project $sshServer:/paytm/NewBuild/
validateStep "scp resources to NewBuild"

scp -r $WORKSPACE/mapping-service-update-consumer/target/mapping-service-update-consumer $sshServer:/paytm/NewBuild/
validateStep "scp project folder to NewBuild"

ssh -T  $sshServer  "ps aux | grep 'mapping.service.update.consumer'| grep -v grep|awk '{print \$2}' | xargs kill -9"

ssh -T  $sshServer cp -r /paytm/mapping-service-update-consumer  $backupPath/mapping-service-integration_$CurrentTime
validateStep "backup project"

ssh -T $sshServer cp -r  /paytm/NewBuild/mapping-service-update-consumer /paytm/
validateStep "copy project folder to paytm"

ssh -T $sshServer rsync --remove-source-files -a /etc/appconf/project/*  /etc/appconf/project_bckup
validateStep "backup old properties"

ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "copy updated project properties to appconf"

nohup ssh -T $sshServer sh /paytm/mapping-service-update-consumer/bin/startserver.sh &

