profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
   	sshServer=dev@10.144.18.118
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.117
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.168
elif [ $1 = qa4 ]
then
	sshServer=pgtest@10.142.51.234	
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.240
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/notification-queue-handler/project $sshServer:/paytm/NewBuild/

cd $WORKSPACE;
mvn clean install  -DskipTests -P$1 -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi

scp -r $WORKSPACE/notification-queue-handler/target/notification-queue-handler $sshServer:/paytm/NewBuild/

echo $sshServer
ssh -T  $sshServer  "ps aux | grep 'NotificationQueueHandlerApplication'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/notification-queue-handler  $backupPath/notification-queue-handler_$CurrentTime
if [ $? -eq 0 ]; then
    echo "backup done"
else
    echo "backup fail"
fi
ssh -T $sshServer mv /paytm/NewBuild/notification-queue-handler /paytm/
if [ $? -eq 0 ]; then
    echo "folder copy to  paytm success"
else
    echo "folder copy to paytm  fail"
fi
ssh -T $sshServer rm -rf /etc/appconf/project_old/project
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_old
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf project copy success"
else
    echo "appconf project folder copy  fail"
fi

ssh -T $sshServer "cd /paytm/notification-queue-handler/bin; nohup sh startserver.sh >> nohup.out 2>&1 &"
echo "notification queue handler started "
