#!/bin/bash
. ./commonFunctions.sh

profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
    	sshServer=dev@10.144.18.119
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.209
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.174
elif [ $1 = qa4 ]
then
	sshServer=pgtest@10.142.52.29
elif [ $1 = qa5 ]
then 
	sshServer=pgptest@10.142.52.35
else
    	echo Incorrect profile
	exit 1
fi

cd $WORKSPACE; mvn clean install  -DskipTests  -e
validateStep "build project"

scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/mapping-service-migration-consumer/project $sshServer:/paytm/NewBuild
validateStep "scp resources to NewBuild"

scp -r $WORKSPACE/mapping-service-migration-consumer/target/mapping-service-migration-consumer $sshServer:/paytm/NewBuild/
validateStep "scp project folder to NewBuild"

ssh -T  $sshServer  "ps aux | grep 'mapping-service-migration-consumer'| grep -v grep|awk '{print \$2}' | xargs kill -9"

ssh -T  $sshServer cp -r /paytm/mapping-service-migration-consumer  $backupPath/mapping-service-integration_$CurrentTime
validateStep "backup project"

ssh -T $sshServer cp -r  /paytm/NewBuild/mapping-service-migration-consumer /paytm/
validateStep "copy project folder to paytm"

ssh -T $sshServer rsync --remove-source-files -a /etc/appconf/project/*  /etc/appconf/project_bckup
validateStep "backup old properties"

ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
validateStep "copy updated project properties"

nohup ssh -T $sshServer sh /paytm/mapping-service-migration-consumer/bin/startserver.sh &

