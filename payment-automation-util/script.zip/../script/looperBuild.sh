profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup 

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
   	sshServer=dev@10.144.18.112
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.115
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.190
elif [ $1 = qa4 ]
then
	sshServer=pgtest@10.142.51.225
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.82
else
    	echo Incorrect profile
	exit 1
fi

scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/looper-service/project/ $sshServer:/paytm/NewBuild/

cd $WORKSPACE;
mvn clean install  -DskipTests -P$profileName -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi

scp -r  $WORKSPACE/looper-service/target/looper-service $sshServer:/paytm/NewBuild/

ssh -T  $sshServer  "ps aux | grep 'looper'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/looper-service  $backupPath/looper_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer mv  /paytm/NewBuild/looper-service /paytm/
if [ $? -eq 0 ]; then
    echo "folder copy to  paytm success"
else
    echo "folder copy to paytm  fail"
fi
ssh -T $sshServer rm -rf /etc/appconf/project_bckup
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_bckup
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updated successfully"
fi
nohup ssh -T $sshServer sh /paytm/looper-service/bin/startserver.sh &

