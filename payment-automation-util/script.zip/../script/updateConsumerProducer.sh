#!/bin/bash
. ./commonFunctions.sh

profile=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profile
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $profile = auto ]
then
    	sshServer=dev@10.144.18.116
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.104
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.166
elif [ $1 = qa4 ]
then
   	sshServer=pgtest@10.142.52.29
elif [ $1 = qa5 ]
then
   	sshServer=pgtest@10.142.52.26
else
    	echo Incorrect profile
	exit 1
fi
ssh -T  $sshServer rm -r /paytm/NewBuild/update-consumer
scp -r $WORKSPACE/update-consumer/target/update-consumer $sshServer:/paytm/NewBuild/
validateStep "scp project folder to NewBuild"
ssh -T  $sshServer  "ps aux | grep 'update-consumer'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/update-consumer  $backupPath/update-consumer_$CurrentTime
validateStep "backup project"
ssh -T $sshServer cp -r  /paytm/NewBuild/update-consumer /paytm/
validateStep "copy project folder to paytm folder"
scp -r $WORKSPACE/../Build-Resources/pgp_$profile/update-consumer/extra/* $sshServer:/paytm/update-consumer/resources/qa
validateStep "scp resources to /paytm/update-consumer/resources/qa"
#ssh -T $sshServer sh  /paytm/script/editAerospike.sh $1 update-consumer
#validateStep "update aerospike properties"
#ssh -T $sshServer sh  /paytm/script/editProject.sh $1 update-consumer
#validateStep "update project properties"
#ssh -T $sshServer sh  /paytm/script/editQueue.sh $1 update-consumer
#validateStep "update queue properties"
ssh -T $sshServer "cd /paytm/update-consumer/bin; nohup sh startserver_qa.sh >> nohup.out 2>&1 &"
validateStep "start service"
