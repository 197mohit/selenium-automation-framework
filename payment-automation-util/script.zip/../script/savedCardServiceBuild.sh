profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/savedcard_service/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
        sshServer=dev@10.144.18.110
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.192
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.146
elif [ $1 = qa4 ]
then 
	sshServer=pgtest@10.142.51.217
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.245
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/savecardservice/project/ $sshServer:/paytm/NewBuild/

cd $WORKSPACE;
mvn clean install  -DskipTests  -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi
echo $sshServer:/paytm/NewBuild/
scp $WORKSPACE/savedcardservice/target/savedcardservice.war $sshServer:/paytm/NewBuild/
if [ $? -eq 0 ]; then
    echo "Build transfer to destination  successful"
else
    echo "Build transfer to destination failed "
    exit;
fi
echo $sshServer
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/savedcardservice  $backupPath/savedcardservice_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/savedcardservice.war $tomcatPath/webapps/savedcardservice.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer rm -rf /etc/appconf/project_bckup
ssh -T $sshServer mv /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer mv  /paytm/NewBuild/project /etc/appconf
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed"
fi

ssh -T $sshServer sh $tomcatPath/bin/startup.sh

