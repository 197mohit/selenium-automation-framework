. /paytm/script/new-scripts/commonFunctions.sh
if [ $1 = staging ]
then
   array=(10.142.51.135 10.142.51.164 10.142.51.142 10.142.51.148 10.142.51.147 10.142.51.162 10.142.51.150 10.142.51.175 10.142.51.146 10.142.51.157 10.142.51.159 10.142.52.115 10.142.51.139 10.142.51.136 10.142.51.154)
   user=staging
   password=Pst@ging
   dbServer=10.142.51.84
elif [ $1 = ite ]
then 
   array=(10.142.51.201 10.142.51.172 10.142.51.205 10.142.51.210 10.142.51.207 10.142.51.206 10.142.51.207 10.142.51.210 10.142.51.222	10.142.51.217 10.142.51.200 10.142.51.232 10.142.51.230 10.142.51.234 10.142.52.33 10.142.51.220 10.142.51.231)
   user=iteenv
   password=itest@ck
   dbServer=10.142.51.242
elif [ $1 = qa5 ]
then 
   array=(10.142.52.41 10.142.51.203 10.142.51.212 10.142.51.216 10.142.51.208 10.142.51.184 10.142.51.214 10.142.51.221 10.142.51.245 10.142.51.173 10.142.51.250 10.142.51.243)
   jarArray=(10.142.51.218 10.142.51.228 10.142.51.240 10.142.52.28 10.142.52.26)
   user=testqa5
   password=passqa5
   dbServer=10.142.51.253
elif [ $1 = hotfix ]
then
  array=(10.142.51.122 10.142.52.106 10.142.51.102 10.142.51.103 10.142.51.119 10.142.51.113 10.142.51.112 10.142.51.106 10.142.51.192 10.142.51.99 10.142.51.186 10.142.51.89)
  jarArray=(10.142.51.118 10.142.51.124 10.142.51.117 10.142.51.105 10.142.51.104)
  user=pgsudo
  password=pgsudo@123
  dbServer=10.142.51.123
else
    echo Incorrect profile
fi


module=(theia insta mapping-service pgproxy_notification merchant-status refundService pgpplusbo promoService savedcard_service subscription paymentService linkService)
jarModule=(payment-postProcessor communication-gateway notification-queue-handle velocity_service savedcardConsumer)

for i in ${!array[*]}
do
echo ${array[$i]}
echo ${module[$i]}
sshServer=${array[$i]}
tomcatModuleName=${module[$i]}
echo changing $moduleName on ip $sshServer
#sshpass -p P$password   ssh  $user@$sshServer "sudo sed -i '/sessionRedisUrl/c\sessionRedisUrl=redis:\/\/10.152.53.42:6379\/0' /etc/appconf/redis.properties"
automationDB=10.144.18.122
sshpass -p $password   ssh  $user@$sshServer "sudo sed -i '/$automationDB/$dbServer/g' /etc/appconf/persistence-context.properties"
tomcatPath=/paytm/$tomcatModuleName/apache-tomcat
sh /paytm/script/new-scripts/restartScript/tomcat.sh $sshServer $tomcatPath 
done

for i in ${!jarArray[*]}
do
echo ${jarArray[$i]}
echo ${jarModule[$i]}
sshServer=${jarArray[$i]}
jarModuleName=${jarModule[$i]}
echo changing $moduleName on ip $sshServer
#sshpass -p P$password   ssh  $user@$sshServer "sudo sed -i '/sessionRedisUrl/c\sessionRedisUrl=redis:\/\/10.152.53.42:6379\/0' /etc/appconf/redis.properties"
automationDB=10.144.18.122
sshpass -p $password   ssh  $user@$sshServer "sudo sed -i '/$automationDB/$dbServer/g' /etc/appconf/persistence-context.properties"
jatPath=/paytm/$jarModuleName
sh /paytm/script/new-scripts/restartScript/jar.sh $sshServer $jarPath $jarModuleName
done

