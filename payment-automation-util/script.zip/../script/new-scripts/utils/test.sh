. /paytm/script/new-scripts/commonFunctions.sh
if [ $1 = automation ]
then
  array=("10.144.18.101" "10.144.18.102" "10.144.18.103" "10.144.18.107" "10.144.18.105" "10.144.18.106" "10.144.18.104" "10.144.18.108" "10.144.18.110" "10.144.18.111" "10.144.18.117" "10.144.18.118")
  user=dev
  password=Sand@Box25
elif [ $1 = hotfix ]
then
  array=(10.142.51.122 10.142.51.109 10.142.51.102 10.142.51.103 10.142.51.119 10.142.51.113 10.142.51.119 10.142.51.112 10.142.51.106 10.142.51.192 10.142.51.99 10.142.51.118 10.142.51.124 10.142.51.117 10.142.51.105 10.142.51.186)
  user=pgsudo
  password=pgsudo@123
elif [ $1 = staging ]
then
   array=(10.142.51.135 10.142.51.164 10.142.51.142 10.142.51.148 10.142.51.147 10.142.51.162 10.142.51.150 10.142.51.175 10.142.51.146 10.142.51.157 10.142.51.159 10.142.52.115 10.142.51.139 10.142.51.136 10.142.51.154)
   user=staging
   password=Pst@ging
elif [ $1 = ite ]
then 
   array=(10.142.52.38 10.142.51.201 10.142.51.172 10.142.51.210 10.142.51.207 10.142.51.206 10.142.51.207 10.142.51.210 10.142.51.222	10.142.51.217 10.142.51.200 10.142.51.232 10.142.51.230 10.142.51.234 10.142.52.33 10.142.51.220 10.142.51.231)
   user=iteenv
   password=itest@ck
elif [ $1 = qa5 ]
then 
   array=(10.142.52.41 10.142.51.203 10.142.51.212 10.142.51.216 10.142.51.208 10.142.51.184 10.142.51.208 10.142.51.214 10.142.51.221 10.142.51.245 10.142.51.173 10.142.52.26 10.142.51.218 10.142.51.228 10.142.51.240 10.142.52.28 10.142.51.243 10.142.51.250)
   user=testqa5
   password=passqa5
else
    echo Incorrect profile
fi
#module=(theia insta mapping-service pgproxy_notification merchant-status )
for i in ${!array[*]}
do
echo ${array[$i]}
echo ${module[$i]}
sshServer=${array[$i]}
#moduleName=${module[$i]}
FileName=$2;
Destination=$3;
sshpass -p $password ssh $user@$sshServer "sudo mkdir $FileName"
#echo sshpass -p $password ssh $user@$sshServer "sudo cp -r $Destination/$FileName $Destination/$4"
#sshpass -p $password ssh $user@$sshServer "sudo cp -r $Destination/$FileName $Destination/$4"
#sshpass -p $password   scp -r /tmp/$FileName $user@${array[$i]}:/tmp
#validateStep "file copy to tmp"
#sshpass -p $password ssh $user@$sshServer "sudo cp -r /tmp/$FileName $Destination"
#validateStep "file copy to payment engine"
done
