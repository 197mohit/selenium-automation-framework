. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
WORKSPACE=$2
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/savedcard_service/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
        sshServer=dev@10.144.18.110
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.192
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.146
elif [ $1 = ite ]
then 
	sshServer=pgtest@10.142.51.217
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.245
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.65
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/savedcardservice/project/ $sshServer:/paytm/NewBuild/

echo $sshServer:/paytm/NewBuild/
scp $WORKSPACE/../build-saved-card/savedcardservice/target/savedcardservice.war $sshServer:/paytm/NewBuild/
validateStep "Build transfer to destination"
echo $sshServer
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/savedcardservice  $backupPath/savedcardservice_$CurrentTime
#validateStep "Old build backup"
ssh -T $sshServer cp  /paytm/NewBuild/savedcardservice.war $tomcatPath/webapps/savedcardservice.war
validateStep "war copy to webapps"
ssh -T $sshServer rm -rf /etc/appconf/project_bckup
ssh -T $sshServer mv /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf
validateStep "appconf folder updated"

ssh -T $sshServer sh $tomcatPath/bin/startup.sh

