. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
WORKSPACE=$2
cronName=$3
CurrentTime=`date +"%H-%d-%m"`
tomcatPath=/paytm/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup

if [ $1 = automation ]
then
        sshServer=dev@10.144.18.106
echo"cron is not setup"
exit 1;
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.76
elif [ $1 = ite ]
then
   sshServer=pgtest@10.142.52.25
elif [ $1 = pos ]
then
   sshServer=pgtest@10.142.52.197
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.52.47
else
    echo Incorrect profile
    exit 1
fi
echo "cron is deploying to "$sshServer
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
scp -r  $WORKSPACE/../Build-Resources/pgp_$profileName/cron_jobs/project $sshServer:/paytm/NewBuild/
validateStep "project copy to newbuild"
scp -r  $WORKSPACE/../build-cron-job/scheduler/target/scheduler/*  $sshServer:/paytm/NewBuild/
validateStep "bin and lib copy to newbuild"
ssh -T $sshServer "mv  /paytm/scheduler/scheduler/$cronName $backupPath/$cronName'_'$CurrentTime"
ssh -T $sshServer "mkdir /paytm/scheduler/scheduler/$cronName"
ssh -T $sshServer "cp -r /paytm/NewBuild/* /paytm/scheduler/scheduler/$cronName"
validateStep "cron copied from newbuild to /paytm/scheduler/scheduler/$cronName"
#ssh -T $sshServer "sh /paytm/scheduler/scheduler/$cronName/bin/startserver.sh start $cronName"
#validateStep "cron start"
echo "project has been copied to /paytm/NewBuild/, please update appconf if changes is there in project and restart cron manually with command >>>>>>sh /paytm/scheduler/scheduler/$cronName/bin/startserver.sh start $cronName"
exit 1;
