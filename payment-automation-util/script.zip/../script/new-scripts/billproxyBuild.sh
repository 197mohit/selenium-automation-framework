. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/billproxy/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup
WORKSPACE=$2
source /paytm/script/EnvDetails/$profileName'.sh'
sshServer=$billproxyServer;
cd $WORKSPACE
echo "sshserver" $sshServer;
echo "Profile selected:::"$profileName
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
validateStep "newbuild cleared"
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/billproxy/project $sshServer:/paytm/NewBuild/
validateStep "copy project folder to NewBuild"
scp $WORKSPACE/../build-billproxy/billproxy/target/billproxy.war $sshServer:/paytm/NewBuild/
validateStep "billproxy war copy to newbuild"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv  $tomcatPath/webapps/billproxy  $backupPath/billproxy_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/billproxy.war $tomcatPath/webapps/billproxy.war
validateStep "war copy to webapps"
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "projct copy to appconf from newbuild"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
