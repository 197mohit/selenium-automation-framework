. /paytm/script/new-scripts/commonFunctions.sh
if [ $1 = automation ]
then
  array=("10.144.18.101" "10.144.18.102" "10.144.18.103" "10.144.18.107" "10.144.18.105" "10.144.18.106" "10.144.18.104" "10.144.18.108" "10.144.18.110" "10.144.18.111" "10.142.51.88" "10.142.51.70")
  jarArray=(10.144.18.115 10.144.18.117	10.144.18.118 10.142.51.91 10.144.18.110)
  user=dev
  password=Sand@box25
  tomcatUser=dev
elif [ $1 = hotfix ]
then
  array=(10.142.51.122 10.142.52.106 10.142.51.102 10.142.51.103 10.142.51.119 10.142.51.113 10.142.51.112 10.142.51.106 10.142.51.192 10.142.51.99 10.142.51.186 10.142.51.89)
  jarArray=(10.142.51.118 10.142.51.124 10.142.51.117 10.142.51.105 10.142.51.104)
  user=pgsudo
  password=pgsudo@123
  tomcatUser=pgtest
elif [ $1 = staging ]
then
   array=(10.142.51.135 10.142.51.164 10.142.51.142 10.142.51.148 10.142.51.147 10.142.51.162 10.142.51.174 10.142.51.150 10.142.51.146 10.142.51.157 10.142.51.154 10.142.51.139)
   jarArray=(10.142.51.175 10.142.51.159 10.142.52.115 10.142.51.152 10.142.51.146)
   user=staging
   password=Pst@ging
   tomcatUser=pgtest
elif [ $1 = ite ]
then 
   array=(10.142.51.201 10.142.51.201 10.142.52.61 10.142.51.210 10.142.51.207 10.142.51.206 10.142.51.213 10.142.51.222 10.142.51.217 10.142.51.200 10.142.51.231 10.142.51.220)
   jarArray=(10.142.51.232 10.142.51.230 10.142.51.234 10.142.52.33 10.142.52.29)
   user=iteenv
   password=itest@ck
   tomcatUser=pgtest
elif [ $1 = qa5 ]
then 
   array=(10.142.52.41 10.142.51.203 10.142.51.212 10.142.51.216 10.142.51.208 10.142.51.184 10.142.51.214 10.142.51.221 10.142.51.245 10.142.51.173 10.142.51.250 10.142.51.243)
   jarArray=(10.142.51.218 10.142.51.228 10.142.51.240 10.142.52.28 10.142.52.26)
   user=testqa5
   password=passqa5
   tomcatUser=pgtest
elif [ $1 = qa6 ]
then
   array=(10.142.52.41 10.142.51.203 10.142.51.212 10.142.51.216 10.142.51.208 10.142.51.184 10.142.51.208 10.142.51.214 10.142.51.221 10.142.51.245 10.142.51.173 10.142.52.26 10.142.51.218 10.142.51.228 10.142.51.240 10.142.52.28 10.142.51.243 10.142.51.250)
   user=pgpuser
   password=paytm@123
elif [ $1 = qa7 ]
then
   array=(10.142.52.41 10.142.51.203 10.142.51.212 10.142.51.216 10.142.51.208 10.142.51.184 10.142.51.208 10.142.51.214 10.142.51.221 10.142.51.245 10.142.51.173 10.142.52.26 10.142.51.218 10.142.51.228 10.142.51.240 10.142.52.28 10.142.51.243 10.142.51.250)
   user=testqa5
   password=passqa5
else
    echo Incorrect profile
fi

module=(theia insta mapping-service pgproxy_notification merchant-status refundService pgpplusbo promoService savedcard_service subscription paymentService linkService)
jarModule=(payment-postProcessor communication-gateway notification-queue-handle velocity_service savedcardConsumer)

for i in ${!array[*]}
do
sshServer=${array[$i]}
echo changing on module ${module[$i]} on $sshServer
tomcatModuleName=${module[$i]}
FileName=$2;
Destination=$3;
echo sshpass -p $password  scp -r /tmp/$FileName $user@${array[$i]}:/tmp
sshpass -p $password  scp -r /tmp/$FileName $user@${array[$i]}:/tmp
continueToNext "scp to ${array[$i]}"
sshpass -p $password ssh $user@$sshServer "sudo mkdir $Destination"
sshpass -p $password ssh $user@$sshServer "sudo cp -r /tmp/$FileName $Destination"
continueToNext "file copy from tmp to payment engine"
tomcatPath=/paytm/$tomcatModuleName/apache-tomcat
sh /paytm/script/new-scripts/restartScript/tomcat.sh $tomcatUser@$sshServer $tomcatPath
done

for i in ${!jarArray[*]}
do
echo changing on ${jarModule[$i]} on IP  ${jarArray[$i]}
sshServer=${jarArray[$i]}
jarModuleName=${jarModule[$i]}
sshpass -p $password  scp -r /tmp/$FileName $user@${jarArray[$i]}:/tmp
continueToNext "scp to ${jarArray[$i]}"
sshpass -p $password ssh $user@$sshServer "sudo mkdir $Destination"
sshpass -p $password ssh $user@$sshServer "sudo cp -r /tmp/$FileName $Destination"
continueToNext "file copy from tmp to payment engine"
jarPath=/paytm/$jarModuleName
sh /paytm/script/new-scripts/restartScript/jar.sh $tomcatUser@$sshServer $jarPath $jarModuleName
done
