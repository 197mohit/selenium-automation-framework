sshServer=$1
jarPath=$2
moduleName=$3
. /paytm/script/new-scripts/commonFunctions.sh
pid=$(ssh -T $sshServer  "ps aux | grep '$moduleName'| grep -v grep|awk '{print \$2}'")
echo old pid: $pid

ssh -T $sshServer  "ps aux | grep '$moduleName'| grep -v grep|awk '{print \$2}' | xargs kill -9"
validateStep "killed pid: $pid"
nohup ssh -T $sshServer sh $jarPath/bin/startserver.sh &
pidNew=$(ssh -T $sshServer  "ps aux | grep '$moduleName'| grep -v grep|awk '{print \$2}'")
echo new pid: $pidNew
if [ $pid = $pidNew ]
then
        echo "server not started successfully"
        exit 1;
else
        echo "server started successfully"
fi
validateStep "insta started"
