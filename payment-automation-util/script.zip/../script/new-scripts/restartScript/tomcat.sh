sshServer=$1
tomcatPath=$2
. /paytm/script/new-scripts/commonFunctions.sh
pid=000
pid=$(ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}'")
echo old pid: $pid

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
validateStep "killed pid: $pid"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
pidNew=$(ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}'")
echo new pid: $pidNew
if [ $pid = $pidNew ]
then
        echo "server not started successfully"
        exit 1;
else
        echo "server started successfully"
fi
validateStep "server started"
