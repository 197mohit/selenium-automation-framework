. /paytm/script/commonFunctions.sh
CurrentTime=`date +"%m-%d-%Y-%N"`
profileName=$1
tomcatPath=/paytm/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup
source /paytm/script/EnvDetails/$profileName'.sh'
sshServer=$adminServer;
if [ $1 = automation ]
then
        sshServer=dev@10.144.18.116
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.93
elif [ $1 = ite ]
then
   sshServer=pgtest@10.142.52.31
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.52.32
elif [ $1 = pos ]
then
   sshServer=pgtest@10.142.52.136
elif [ $1 = qa6 ]
then
   sshServer=pgtest@10.142.52.228
else
    echo Incorrect profile
    exit 1
fi
echo $sshServer
WORKSPACE=$2
cd $WORKSPACE;
scp $WORKSPACE/../build-admin-panel/admin/target/admin.war  $sshServer:/paytm/NewBuild/
validateStep "war copy to destination SUCCESS"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/admin  $backupPath/admin_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/admin.war $tomcatPath/webapps/admin.war
validateStep "copy admin war to tomcat "
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
sleep 15
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
scp -r /paytm/script/new-scripts/producer_admin_scripts/$1/script $sshServer:/paytm
ssh -T $sshServer sh  /paytm/script/editAerospike.sh $1 admin
validateStep "update aerospike properties"
ssh -T $sshServer sh  /paytm/script/editProject.sh $1 admin
validateStep "update project properties"
ssh -T $sshServer sh  /paytm/script/editQueue.sh $1 admin
validateStep "update queue properties"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
validateStep "Tomcat started"
