. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/refundService/apache-tomcat
backupPath=/paytm/BuildBckup
WORKSPACE=$2
source /paytm/script/EnvDetails/$profileName'.sh'
sshServer=$refundServer;
echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

cd $WORKSPACE/..

if [ $1 = automation ]
then
   sshServer=dev@10.144.18.104
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.113
elif [ $1 = staging ]
then
   sshServer=pgtest@10.142.51.162
elif [ $1 = ite ]
then 
   sshServer=pgtest@10.142.51.206
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.51.184
elif [ $1 = pos ]
then
   sshServer=pgtest@10.142.52.155
elif [ $1 = PGP-AccountingPlus-1 ]
then
   sshServer=pgtest@10.142.52.207
fi
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
echo "copying resources to server: " $sshServer
scp -r Build-Resources/pgp_$profileName/refund/project $sshServer:/paytm/NewBuild/
validateStep "project copy to newbuild"
scp $WORKSPACE/../build-refund-service/refund/target/refund.war $sshServer:/paytm/NewBuild/
validateStep "refund war copy to newbuild"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv  $tomcatPath/webapps/refund  $backupPath/refund_$CurrentTime
validateStep "Old build backup "
ssh -T $sshServer cp /paytm/NewBuild/refund.war $tomcatPath/webapps/refund.war
validateStep "war copy to webapps "
ssh -T $sshServer 'rm -rf /etc/appconf/project_bckup/*'
ssh -T $sshServer 'mv  /etc/appconf/project/*  /etc/appconf/project_bckup'
ssh -T $sshServer 'cp -r /paytm/NewBuild/project /etc/appconf/'
validateStep "appconf folder updated"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
