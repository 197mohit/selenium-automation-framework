string1=$1
string2=$2
case "$string1" in
    *$string2* )
        exit 1;
        ;;
    *) exit 0;
esac
