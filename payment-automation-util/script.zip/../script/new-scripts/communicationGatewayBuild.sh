#!/bin/bash
. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup
WORKSPACE=$2

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
       	sshServer=dev@10.144.18.117
elif [ $1 = hotfix ]
then 
   	sshServer=pgtest@10.142.51.124
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.159
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.51.230
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.228
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.199
else
    	echo Incorrect profile
	exit 1
fi
ssh -T  $sshServer "rm -rf /paytm/NewBuild/*"
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/communication-gateway/project/ $sshServer:/paytm/NewBuild/
validateStep "scp resources to NewBuild"
scp -r $WORKSPACE/../build-pgproxy-notification/communication-gateway/target/communication-gateway $sshServer:/paytm/NewBuild/
validateStep "scp project folder to NewBuild"
ssh -T  $sshServer  "ps aux | grep 'CommunicationGatewayApplication'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/communication-gateway  $backupPath/communication-gateway_$CurrentTime
validateStep "backup project"
ssh -T $sshServer cp -r /paytm/NewBuild/communication-gateway /paytm/
validateStep "copy project folder to paytm"
ssh -T $sshServer "mv /etc/appconf/project/* /etc/appconf/project_bckup"
validateStep "backup old properties"
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf
validateStep "copy updated project properties"
ssh -T $sshServer sed -i '1iotp.mask.enable=false'  /etc/appconf/project/project-notification.properties
validateStep "otp mask property add"
ssh -T $sshServer "cd /paytm/communication-gateway/bin; nohup sh startserver.sh >> nohup.out 2>&1 &"
validateStep "server started"; 
