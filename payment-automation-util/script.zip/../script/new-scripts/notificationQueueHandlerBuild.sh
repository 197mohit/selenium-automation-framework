. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup
WORKSPACE=$2
echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE
source /paytm/script/EnvDetails/$profileName'.sh'
sshServer=$queueHandlerServer;
if [ $1 = automation ]
then
   	sshServer=dev@10.144.18.118
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.117
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.52.115
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.51.234	
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.240
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.176
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/notification-queue-handler/project $sshServer:/paytm/NewBuild/
validateStep "resources copy to newbuild"
scp -r $WORKSPACE/../build-pgproxy-notification/notification-queue-handler/target/notification-queue-handler $sshServer:/paytm/NewBuild/
validateStep "queue handler copy to newbuild"
ssh -T  $sshServer  "ps aux | grep 'NotificationQueueHandlerApplication'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/notification-queue-handler  $backupPath/notification-queue-handler_$CurrentTime
ssh -T $sshServer mv /paytm/NewBuild/notification-queue-handler /paytm/
validateStep "build copy to /paytm from new build"
ssh -T $sshServer rm -rf /etc/appconf/project_old/project
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_old
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "project copy from newbuild to appconf"
ssh -T $sshServer "cd /paytm/notification-queue-handler/bin; nohup sh startserver.sh >> nohup.out 2>&1 &"
echo "notification queue handler started "
