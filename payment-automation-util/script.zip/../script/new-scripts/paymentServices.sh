validateStep() {
if [ $? -eq 0 ]; then
    	echo "step $1 successfully completed"
else
    	echo "step $1 failed so, terminating script"
	exit 1
fi
}

profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/paymentService/apache-tomcat
backupPath=/paytm/BuildBckup
WORKSPACE=$2
source /paytm/script/EnvDetails/$profileName'.sh'
sshServer=$promoServer;

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
	sshServer=pgtest@10.142.51.70
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.186
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.154
elif [ $1 = ite ]
then
   	sshServer=pgtest@10.142.51.231
elif [ $1 = qa5 ]
then
   	sshServer=pgtest@10.142.51.250
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.187
elif [ $1 = qa6 ]
then
        sshServer=pgtest@10.142.52.156
elif [ $1 = PGP-AccountingPlus-1 ]
then
        sshServer=pgtest@10.142.52.134
fi

echo "copying resources to server: " $sshServer
#scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/payment_services/project $sshServer:/paytm/NewBuild/
#validateStep "copy resources"
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
scp $WORKSPACE/../build-payment-service/target/*.war $sshServer:/paytm/NewBuild/paymentservices.war
#coping resources
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/paymentservices/project $sshServer:/paytm/NewBuild/

validateStep "war copy to newbuild";
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/paymentservices  $backupPath/paymentservices_$CurrentTime

#Moving Resources to /etc/appconf
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "Backup"
ssh -T $sshServer cp  /paytm/NewBuild/paymentservices.war $tomcatPath/webapps/
validateStep "War copy to webapps"

if [ $1 = qa5 ]
then
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/paymentservices/mock_project $sshServer:/paytm/NewBuild/
ssh -T $sshServer cp -r /paytm/NewBuild/mock_project /etc/appconf/
echo "mock project copied to appconf"
fi

#ssh -T $sshServer rsync --remove-source-files -zvh /etc/appconf/project/  /etc/appconf/project_bckup
#ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
#echo "properties and pointings needs to be changed to be changed"
#exit 1;
