#!/bin/bash
. /paytm/script/new-scripts/commonFunctions.sh
WORKSPACE=/paytm/jenkins_home/workspace/migration-producers
profile=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup
source /paytm/script/EnvDetails/$profile'.sh'
sshServer=$producersServer;
echo "profile: " $profile
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
    	sshServer=dev@10.144.18.116
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.104
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.166
elif [ $1 = ite ]
then
   	sshServer=pgtest@10.142.52.29
elif [ $1 = qa5 ]
then
   	sshServer=pgtest@10.142.52.26
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.160
elif [ $1 = perf ]
then
        sshServer=root@10.144.13.52
fi
ssh -T  $sshServer rm -r /paytm/NewBuild/parent-producer
echo '>>>'$WORKSPACE'/../build-migration-producers/parent-producer/target/parent-producer'
scp -r $WORKSPACE/../build-migration-producers/parent-producer/target/parent-producer $sshServer:/paytm/NewBuild/
validateStep "scp project folder to NewBuild"
ssh -T $sshServer  "ps aux | grep 'parent-producer'| grep -v grep|awk '{print \$2}' | xargs kill -9"
echo mv /paytm/parent-producer  $backupPath/parent-producer_$CurrentTime
ssh -T  $sshServer "mv /paytm/parent-producer  $backupPath/parent-producer_$CurrentTime"
validateStep "backup project"
ssh -T $sshServer cp -r  /paytm/NewBuild/parent-producer /paytm/
validateStep "copy project folder to paytm folder"
#scp -r $WORKSPACE/../Build-Resources/pgp_$profile/update-consumer/extra/* $sshServer:/paytm/update-consumer/resources/qa
#validateStep "scp resources to /paytm/update-consumer/resources/qa"

#validateStep "copy project folder to paytm folder"
scp -r /paytm/script/new-scripts/producer_admin_scripts/$1/script $sshServer:/paytm
ssh -T $sshServer sh  /paytm/script/editAerospike.sh $1 parent-producer
validateStep "update aerospike properties"
ssh -T $sshServer sh  /paytm/script/editProject.sh $1 parent-producer
validateStep "update project properties"
ssh -T $sshServer sh  /paytm/script/editQueue.sh $1 parent-producer
validateStep "update queue properties"
ssh -T $sshServer "cd /paytm/parent-producer/bin; nohup sh startserver_qa.sh >> nohup.out 2>&1 &"
validateStep "start service"
