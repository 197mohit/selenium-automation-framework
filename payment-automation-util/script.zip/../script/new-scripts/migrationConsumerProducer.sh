#!/bin/bash
. /paytm/script/new-scripts/commonFunctions.sh
profile=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profile
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE
source /paytm/script/EnvDetails/$profile'.sh'
sshServer=$producersServer;
if [ $1 = automation ]
then
    	sshServer=dev@10.144.18.116
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.104
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.166
elif [ $1 = ite ]
then
   	sshServer=pgtest@10.142.52.29
elif [ $1 = qa5 ]
then
   	sshServer=pgtest@10.142.52.26
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.160
fi
ssh -T  $sshServer rm -r /paytm/NewBuild/migration-consumer
scp -r $WORKSPACE/../build-migration-producers/migration-consumer/target/migration-consumer $sshServer:/paytm/NewBuild/
validateStep "scp project folder to NewBuild"
ssh -T  $sshServer  "ps aux | grep 'migration-consumer'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer "mv /paytm/migration-consumer  $backupPath/migration-consumer_$CurrentTime"
validateStep "backup existing project"
ssh -T $sshServer cp -r  /paytm/NewBuild/migration-consumer /paytm/
validateStep "copy project folder to paytm folder"
#scp -r $WORKSPACE/../Build-Resources/pgp_$profile/migration-consumer/extra/* $sshServer:/paytm/migration-consumer/resources/qa
#validateStep "scp resources to /paytm/migration-consumer/resources/qa"
scp -r /paytm/script/new-scripts/producer_admin_scripts/$1/script $sshServer:/paytm
ssh -T $sshServer sh  /paytm/script/editAerospike.sh $1  migration-consumer
validateStep "update aerospike properties"
ssh -T $sshServer sh  /paytm/script/editProject.sh $1 migration-consumer
validateStep "update project properties"
ssh -T $sshServer sh  /paytm/script/editQueue.sh $1 migration-consumer
validateStep "update queue properties"
ssh -T $sshServer "cd /paytm/migration-consumer/bin; nohup sh startserver_qa.sh >> nohup.out 2>&1 &"
validateStep "start service"
