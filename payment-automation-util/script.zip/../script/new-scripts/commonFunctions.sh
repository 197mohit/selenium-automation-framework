validateStep() {
if [ $? -eq 0 ]; then
        echo "[STEP] : $1 : SUCCESS"
else
        echo "[STEP] : $1 : FAILED => ABORTING"
        exit 1
fi
}

continueToNext() {
if [ $? -eq 0 ]; then
        echo "[STEP] : $1 : SUCCESS"
else
        echo "[STEP] : $1 : FAILED"
        continue
fi
}
