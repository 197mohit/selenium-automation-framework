. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/promoService/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE
source /paytm/script/EnvDetails/$profileName'.sh'
sshServer=$promoServer;
if [ $1 = auto ]
then
	sshServer=dev@10.144.18.108
elif [ $1 = automation ]
then
        sshServer=dev@10.144.18.108
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.106
elif [ $1 = staging ]
then
        sshServer=pgtest@10.142.51.150
elif [ $1 = ite ]
then 
	sshServer=pgtest@10.142.51.222
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.221
elif [ $1 = PGP-AccountingPlus-1 ]
then
        sshServer=pgtest@10.142.52.92
fi

echo "copying resources to server: " $sshServer
ssh -T $sshServer "rm -rf /paytm/NewBuild/*";
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/promo-service/project $sshServer:/paytm/NewBuild/
validateStep "resources copies to new build"
scp $WORKSPACE/../build-promo-service/promo-service/target/promo-service.war $sshServer:/paytm/NewBuild/
validateStep "war copiy to new build"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/promo-service  $backupPath/promo-service_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/promo-service.war  $tomcatPath/webapps/promo-service.war
validateStep "build copy from newbuild to webapps"
ssh -T $sshServer rm -rf /etc/appconf/project_bckup/project
ssh -T $sshServer mv /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
validateStep "project copy from newbuild to appconf"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh

