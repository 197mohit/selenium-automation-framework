. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/eos/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup
WORKSPACE=$2

echo "Copying configuration from resources Build-Resources/pgp_$profileName/eos/project"
cd $WORKSPACE


if [ $1 = pos ]
then
   sshServer=pgtest@10.142.53.105
else
    echo "Incorrect profile"
	exit 1
fi

echo "ssh server: " $sshServer

echo "Profile selected:::"$profileName
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
validateStep "newbuild cleared"
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/eos/project $sshServer:/paytm/NewBuild/
validateStep "copy project folder to NewBuild"
scp $WORKSPACE/../build-eos/eos/target/eos.war $sshServer:/paytm/NewBuild/
validateStep "eos war copy to newbuild"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv  $tomcatPath/webapps/eos  $backupPath/eos_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/eos.war $tomcatPath/webapps/eos.war
validateStep "war copy to webapps"
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "projct copy to appconf from newbuild"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
sleep 50
#echo 'curl https://pgp-'$1'.paytm.in/instaproxy/healthcheck'
#curl 'https://pgp-'$1'.paytm.in/instaproxy/healthcheck'
#echo 'Health check done'
