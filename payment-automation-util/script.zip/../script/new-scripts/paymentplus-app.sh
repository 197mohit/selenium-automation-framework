. /paytm/script/commonFunctions.sh
Env=$2
Version=$1
source '/paytm/script/EnvDetails/'$Env'.sh'
echo 'ip list  loaded from /paytm/script/EnvDetails'/$Env'.sh'
echo server detail- theia: $theiaServer lighttpd: $lighttpd
cd $WORKSPACE;
npm install --production;
validateStep "npm install";
echo "QA_STATIC_ASSET_HOST="$3 and QA_API_HOST= $4;
QA_STATIC_ASSET_HOST=$3 QA_API_HOST=$4 VERSION=$1 ENV=qa npm run build;
validateStep "build payment app";
#ssh -T pgtest@10.142.51.239 'mv /paytm/lighttpd/pgp /paytm/BuildBckup/pgp_bck'
#scp -r build/pgp pgtest@10.142.51.239:/paytm/lighttpd/
#ssh -T pgtest@10.142.51.239 "chmod -R 775 /paytm/lighttpd/pgp"
#validateStep "pgp folder scp to lighttpd";
#scp -r build/pgp/latest/index.html pgtest@10.142.52.38:/tmp
#validateStep "index.html to tmp";
#scp -r /paytm/script/copyToEtc.sh pgtest@10.142.52.38:/paytm/
#validateStep "Copy script copyToEtc";
#ssh -T pgtest@10.142.52.38 'sh /paytm/copyToEtc.sh index.html'
#validateStep "Copy index.html to appconf/project";
#######################
ssh -T $lighttpd 'mv /paytm/lighttpd/pgp /paytm/BuildBckup/pgp_bck'
scp -r build/pgp $lighttpd:/paytm/lighttpd/
ssh -T $lighttpd "chmod -R 775 /paytm/lighttpd/pgp"
validateStep "pgp folder scp to lighttpd";
#scp -r build/pgp/latest/index.html $secTheiaServer:/tmp
#validateStep "index.html to secondry tmp";
scp -r build/pgp/latest/index.html $theiaServer:/tmp
validateStep "index.html to primary tmp";
#scp -r /paytm/script/copyToEtc.sh $secTheiaServer:/paytm/
#validateStep "Copy script secondry copyToEtc";
scp -r /paytm/script/copyToEtc.sh $theiaServer:/paytm/
validateStep "Copy script to primary  copyToEtc";
#ssh -T $secTheiaServer 'sh /paytm/copyToEtc.sh index.html'
#validateStep "Copy index.html to secondry appconf/project";
ssh -T $theiaServer 'sh /paytm/copyToEtc.sh index.html'
validateStep "Copy index.html to primary  appconf/project";
