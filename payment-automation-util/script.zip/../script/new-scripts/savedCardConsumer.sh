. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup
WORKSPACE=$2
echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
    	sshServer=dev@10.144.18.110
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.104
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.146
	echo "server address not provided in script so, terminating script"
elif [ $1 = ite ]
then
   	sshServer=pgtest@10.142.52.29
elif [ $1 = qa5 ]
then
   	sshServer=pgtest@10.142.52.26
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.117
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer

ssh -T  $sshServer "rm -rf /paytm/NewBuild/*"
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/savedcardConsumer/project $sshServer:/paytm/NewBuild/
validateStep "resources copy to newbuild"
scp -r $WORKSPACE/../build-saved-card/savedcardConsumer/target/savedcardConsumer $sshServer:/paytm/NewBuild
validateStep  "saved card consumer copied to newbuild"
ssh -T  $sshServer  "ps aux | grep 'savedcardConsumer'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer "mv /paytm/savedcardConsumer  $backupPath/savedcardConsumer_$CurrentTime"
ssh -T $sshServer "mv  /paytm/NewBuild/savedcardConsumer /paytm/"
validateStep "consumer copy to paytm from newbuild"
ssh -T $sshServer rm -rf /etc/appconf/project_bckup/project
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_bckup
ssh -T $sshServer mv /paytm/NewBuild/project /etc/appconf/project
validateStep "project folder copy from newbuild to appconf"
nohup ssh -T $sshServer sh /paytm/savedcardConsumer/bin/startserver.sh &
validateStep "saved card consumer started"
