. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
        sshServer=root@10.142.51.91
elif [ $1 = automation ]
then
        sshServer=root@10.142.51.91
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.105
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.152
elif [ $1 = ite ]
then
   	sshServer=pgtest@10.142.52.33
elif [ $1 = qa5 ]
then
   	sshServer=pgtest@10.142.52.28
else
    	echo Incorrect profile
	exit 1
fi
ssh -T $sshServer "rm -rf /paytm/NewBuild/*";
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/velocity-service/project $sshServer:/paytm/NewBuild/
#scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/velocity-service/extra $sshServer:/paytm/NewBuild/
cd $WORKSPACE;
scp -r $WORKSPACE/../build-velocity/velocity/target/velocity $sshServer:/paytm/NewBuild/

ssh -T $sshServer  "ps aux | grep 'velocity_service'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv /paytm/velocity_service/velocity $backupPath/velocity_$CurrentTime
ssh -T $sshServer mv  /paytm/NewBuild/velocity /paytm/velocity_service/
validateStep "build copy to destination";
ssh -T $sshServer cp -r  /etc/appconf/project /etc/appconf/project_bckup/
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
validateStep "project copy to appconf"
ssh -T $sshServer cp -r /paytm/NewBuild/extra/* /paytm/velocity_service/velocity/WEB-INF/classes/
nohup ssh -T $sshServer sh /paytm/velocity_service/startserver.sh &
