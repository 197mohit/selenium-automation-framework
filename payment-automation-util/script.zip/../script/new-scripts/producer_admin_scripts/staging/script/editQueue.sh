hotfix=10.142.51.129
staging=10.142.51.149
automation=10.144.18.120
ite=10.142.51.248	
qa5=10.142.51.252
if [ $1 = automation ]
then
    server=$automation
elif [ $1 = hotfix ]
then
   server=$hotfix
elif [ $1 = staging ]
then
   server=$staging
elif [ $1 = ite ]
then
   server=$ite
elif [ $1 = qa5 ]
then
   server=$qa5
echo Incorrect Environment
fi

if [ $2 = admin ]
then
        cd /paytm/apache-tomcat/webapps/admin/WEB-INF/classes/alipay
else
        cd /paytm/$2/resources/qa
fi
#sed -i -e '/rabbitmq.hosts=/c\'rabbitmq.hosts=$server' queue.properties;
sed -i -e 's/mqhost=172.31.40.134/mqhost='$server'/g' queue.properties;
sed -i -e 's/rabbitmq.hosts=172.31.40.134/rabbitmq.hosts='$server'/g' queue.properties;
sed -i -e 's/rabbitmq.hosts=52.76.30.218/rabbitmq.hosts='$server'/g' queue.properties;
sed -i -e 's/rabbitmq.username=guest/rabbitmq.username=test/g' queue.properties;
sed -i -e 's/rabbitmq.password=guest/rabbitmq.password=test/g' queue.properties;
