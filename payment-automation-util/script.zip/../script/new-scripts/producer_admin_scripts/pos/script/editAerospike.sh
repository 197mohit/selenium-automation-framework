hotfix=10.142.51.120
staging=10.142.51.127
automation=10.144.18.121
ite=10.142.52.40
qa5=10.142.52.39
pos=10.142.52.148
if [ $1 = automation ]
then
    server=$automation
elif [ $1 = hotfix ]
then
   server=$hotfix
elif [ $1 = staging ]
then
   server=$staging
elif [ $1 = ite ]
then
   server=$ite
elif [ $1 = qa5 ]
then
   server=$qa5
elif [ $1 = pos ]
then
   server=$pos
else
    echo Incorrect Environment
exit 1;
fi

if [ $2 = admin ]
then
        cd /paytm/apache-tomcat/webapps/admin/WEB-INF/classes/alipay
else
        cd /paytm/$2/resources/qa
fi
#sed -i -e '/aerospike.hosts/c\'aerospike.hosts=$server' aerospike.config;
sed -i -e 's/aerospike.hosts=172.31.40.121/aerospike.hosts='$server'/g' aerospike.config;
sed -i -e 's/aerospike.hosts=localhost/aerospike.hosts='$server'/g' aerospike.config;
