hotfix=10.142.51.123
staging=10.142.51.84
automation=10.144.18.122
ite=10.142.51.242
qa5=10.142.51.253	
pos=10.142.52.146
if [ $1 = auto ]
then
    server=$automation
    domain=automation
elif [ $1 = hotfix ]
then
   server=$hotfix
   domain=hotfix
elif [ $1 = staging ]
then
   server=$staging
   domain=staging
elif [ $1 = ite ]
then
   server=$ite
   domain=ite
elif [ $1 = qa5 ]
then
   server=$qa5
   domain=qa5
elif [ $1 = pos ]
then
   server=$pos
   domain=pos
else
    echo Incorrect Environment
fi
if [ $2 = admin ]
then
        cd /paytm/apache-tomcat/webapps/admin/WEB-INF/classes/alipay
else
        cd /paytm/$2/resources/qa
fi
sed -i -e 's/10.0.100.49:3310/'$server':3310/g' project.properties;
sed -i -e 's/PAYTMPGDB_QA/PAYTMPGDB/g' project.properties; 
sed -i -e 's/172.31.40.132:3310/'$server':3310/g' project.properties;
sed -i -e 's?http://52.76.10.37?https://pgp-'$domain'.paytm.in?g' project.properties;
