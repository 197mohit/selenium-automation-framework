#cd /paytm/lighttpd/$1;
rm -rf /paytm/NewBuild/$2/extractedStatic/*

echo /paytm/NewBuild/$2/extractedStatic/* 
#cp /paytm/NewBuild/theia_static/static.tar /paytm/NewBuild/theia_static/extractedStatic/
cp /paytm/NewBuild/$2/static.tar /paytm/NewBuild/$2/extractedStatic/
cd /paytm/NewBuild/$2/extractedStatic;
tar -xvf static.tar
sudo rm  -rf  /paytm/lighttpd/$1/*
sudo cp -r /paytm/NewBuild/$2/extractedStatic/* /paytm/lighttpd/$1/
cd /paytm/lighttpd/$1;
sudo chmod -R 755 *
sudo service lighttpd restart
