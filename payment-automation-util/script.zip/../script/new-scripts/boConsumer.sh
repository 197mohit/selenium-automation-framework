. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
WORKSPACE=$2
backupPath=/paytm/BuildBckup 
echo "value of"$1
if [ $1 = automation ]
then
    	sshServer=dev@10.144.18.106
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.112
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.174
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.51.213
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.82
else
    echo Incorrect profile
    exit 1;
fi
ssh -T  $sshServer "rm -rf /paytm/NewBuild/*"
cd $WORKSPACE/../
scp -r Build-Resources/pgp_$profileName/bo-consumer/project/ $sshServer:/paytm/NewBuild/
echo $sshServer
cd $WORKSPACE;
scp -r  $WORKSPACE/../build-pg-plus-bo/bo-consumer/target/bo-consumer $sshServer:/paytm/NewBuild/
validateStep "bo-consumer copy to newbuild";
ssh -T  $sshServer  "ps aux | grep 'bo-consumer'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/bo-consumer/bo-consumer  $backupPath/bo-consumer_$CurrentTime
ssh -T $sshServer cp -r  "/paytm/NewBuild/bo-consumer /paytm/bo-consumer/"
validateStep "build copy from newbuild to  paytm ";
ssh -T $sshServer rm -rf /etc/appconf/project_bckup
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_bckup
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
validateStep "project copy from newbuild to appconf";
nohup ssh -T $sshServer sh /paytm/bo-consumer/bo-consumer/bin/start-server.sh &&
validateStep "bo-consumer started";
