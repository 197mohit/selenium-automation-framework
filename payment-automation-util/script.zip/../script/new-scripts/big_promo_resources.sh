. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
echo $tomcatPath
WORKSPACE=$2

cd $WORKSPACE
#insta
#   sshServer=dev@10.142.51.203
 #  profileName=qa5
#ssh -T $sshServer rm -r /paytm/NewBuild/mock_project
#scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/instaproxy/_mockproject $sshServer:/paytm/NewBuild/
#ssh -T $sshServer cp -r /paytm/NewBuild/mock_project /etc/appconf/

#ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
#ssh -T $sshServer sh $tomcatPath/bin/startup.sh
##sleep 50
#echo 'curl https://pgp-'$1'.paytm.in/instaproxy/healthcheck'
#curl 'https://pgp-'$1'.paytm.in/instaproxy/healthcheck'
#echo 'Health check done'

#Theia

   sshServer=dev@10.142.51.198
   profileName=qa5
ssh -T $sshServer rm -r /paytm/NewBuild/mock_project
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/theia/_mockproject $sshServer:/paytm/NewBuild/
ssh -T $sshServer cp -r /paytm/NewBuild/mock_project /etc/appconf/

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
sleep 50
echo 'curl https://pgp-'$1'.paytm.in/theia/healthcheck'
curl 'https://pgp-'$1'.paytm.in/theia/healthcheck'
echo 'Health check done'
