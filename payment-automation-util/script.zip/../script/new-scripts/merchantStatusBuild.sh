. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/merchant-status/apache-tomcat
backupPath=/paytm/BuildBckup
WORKSPACE=$2

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "worspace: " $WORKSPACE

cd $WORKSPACE/..
if [ $1 = automation ]
then
	sshServer=dev@10.144.18.105
elif [ $1 = hotfix ]
then
	sshServer=pgtest@10.142.51.119
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.147
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.51.207
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.208
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.168
else
        echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r Build-Resources/pgp_$profileName/merchant-status/project $sshServer:/paytm/NewBuild/

scp $WORKSPACE/../build-merchant-status/merchant-status/target/merchant-status.war $sshServer:/paytm/NewBuild/
if [ $? -eq 0 ]; then
    echo "Build transfer to destination  successful"
else
    echo "Build transfer to destinaton failed "
    exit;
fi

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/merchant-status  $backupPath/merchant-status_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/merchant-status.war $tomcatPath/webapps/merchant-status.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi

ssh -T $sshServer sh $tomcatPath/bin/startup.sh
                                                                                                                                                             
                          
