. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%N-%d-%m"`
tomcatPath=/paytm/bopanel/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup
WORKSPACE=$2

echo "Copying configuration from resources Build-Resources/pgp_$profileName/instaproxy/project"
cd $WORKSPACE
source /paytm/script/EnvDetails/$profileName'.sh'
validateStep "profile load"
sshServer=$boPanel
echo "ssh server: " $sshServer
echo "Profile selected:::"$profileName
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
validateStep "newbuild cleared"
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/instaproxy/project $sshServer:/paytm/NewBuild/
validateStep "copy project folder to NewBuild"
scp $WORKSPACE/../build-pg-plus-bo/bo-panel/target/bo-panel.war $sshServer:/paytm/NewBuild/
validateStep "pg plus bo  war copy to newbuild"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv  $tomcatPath/webapps/bo-panel  $backupPath/bo-panel_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/bo-panel.war $tomcatPath/webapps/bo-panel.war
validateStep "war copy to webapps"
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "projct copy to appconf from newbuild"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
echo 'Start server done'
