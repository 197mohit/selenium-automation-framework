#!/bin/bash
. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE
source /paytm/script/EnvDetails/$profileName'.sh'
sshServer=$promoServer;
if [ $1 = automation ]
then
    	sshServer=dev@10.144.18.119
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.209
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.158
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.52.120
elif [ $1 = qa5 ]
then 
	sshServer=pgtest@10.142.52.35
	echo "test"
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.151
elif [ $1 = PGP-AccountingPlus-1 ]
then
        sshServer=pgtest@10.142.52.204
fi
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/mapping-service-migration-consumer/project $sshServer:/paytm/NewBuild
validateStep "scp resources to NewBuild"
scp -r $WORKSPACE/../build-mapping-service/mapping-service-migration-consumer/target/mapping-service-migration-consumer $sshServer:/paytm/NewBuild/
validateStep "scp project folder to NewBuild"

ssh -T  $sshServer  "ps aux | grep 'mapping-service-migration-consumer'| grep -v grep|awk '{print \$2}' | xargs kill -9"

ssh -T  $sshServer mv /paytm/mapping-service-migration-consumer  $backupPath/mapping-service-integration_$CurrentTime

ssh -T $sshServer cp -r  /paytm/NewBuild/mapping-service-migration-consumer /paytm/
validateStep "copy project folder to paytm"

ssh -T $sshServer mv /etc/appconf/project/*  /etc/appconf/project_bckup

ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
validateStep "copy updated project properties"

nohup ssh -T $sshServer sh /paytm/mapping-service-migration-consumer/bin/startserver.sh &

