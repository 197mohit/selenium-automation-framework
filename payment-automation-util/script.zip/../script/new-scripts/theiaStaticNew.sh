#!/bin/bash
. /paytm/script/new-scripts/commonFunctions.sh
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/lighttpd
backupPath=/paytm/BuildBckup
sshServer=$2
WORKSPACE=$1
staticFolder=1.2
BuildFolderName=theia_static

echo "profile: " $profile
echo "backup path: " $backupPath
echo "tomcat path: " $tomcatPath
echo "workspace: " $WORKSPACE
echo "server: " $sshServer

cd  $WORKSPACE/../build-theia/static;
tar -cvf static.tar *
scp -r $WORKSPACE/../build-theia/static/static.tar $sshServer:/paytm/NewBuild/$BuildFolderName/
validateStep "scp static tar"
ssh -T $sshServer cp -r  $tomcatPath/$staticFolder  $backupPath/$BuildFolderName$CurrentTime
scp /paytm/script/new-scripts/extractStatic.sh $sshServer:/paytm/script
validateStep "extractStatic.sh script copy"
ssh -T $sshServer sh /paytm/script/extractStatic.sh $staticFolder $BuildFolderName
validateStep "extract static tar"
