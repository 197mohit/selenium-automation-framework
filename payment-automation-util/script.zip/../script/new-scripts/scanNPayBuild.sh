profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/insta/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
    	sshServer=root@10.142.51.80
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.109
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.160
elif [ $1 = ite ]
then
   	sshServer=pgtest@10.142.51.246
elif [ $1 = qa5 ]
then 
   	sshServer=pgtest@10.142.51.226
else
    	echo Incorrect profile
	exit 1
fi

scp $WORKSPACE/scannpay.tar $sshServer:/paytm/NewBuild/

ssh -T  $sshServer pm2 delete scanpay
ssh -T  $sshServer mv  /paytm/scanpay  $backupPath/scanpay-core_$CurrentTime
ssh -T  $sshServer mkdir  /paytm/scanpay
if [ $? -eq 0 ]; then
    echo "backup done"
else
    echo "backup fail"
fi
ssh -T  $sshServer sh /paytm/script/runNodeJs.sh
