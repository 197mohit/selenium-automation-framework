. /paytm/script/new-scripts/commonFunctions.sh
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/theia/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup
WORKSPACE=$1
profileName=$2
sshServer=$3
echo $WORKSPACE ">>>" $profileName ">>>>>>" $sshServer

echo "Copying configuration from resources /Build-Resources/pgp_$profileName/theia/project"
ssh -T $sshServer "rm  -r /paytm/NewBuild/*";
cd $WORKSPACE/..
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
validateStep "Resources copy to $sshServer:/paytm/NewBuild/"
echo "Deployment started on "$profileName;
scp $WORKSPACE/../build-theia/theia/target/theia.war $sshServer:/paytm/NewBuild/
validateStep "war copy to Newbuild"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer "mv $tomcatPath/webapps/theia  $backupPath/theia_$CurrentTime"
ssh -T $sshServer cp  /paytm/NewBuild/theia.war $tomcatPath/webapps/theia.war
validateStep "theia.war copy from NewBuild to webapps";

ssh -T $sshServer mv "/etc/appconf/project/*  /etc/appconf/project_bckup"
ssh -T $sshServer rm -rf /etc/appconf/project/
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/

validateStep "copy project from newbuild to appconf";
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
ssh -T $sshServer sed -i 's#"interval">70#"interval">10#g' /paytm/theia/apache-tomcat/webapps/theia/WEB-INF/classes/log4j2.xml
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
