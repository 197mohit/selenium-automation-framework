. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/pgproxy_notification/apache-tomcat
backupPath=/paytm/BuildBckup
echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
	sshServer=dev@10.144.18.107
elif [ $1 = hotfix ]
then
	sshServer=pgtest@10.142.51.103
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.148
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.51.210
elif [ $1 = qa5 ]
then
        sshServer=pgtest@10.142.51.216
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.139
elif [ $1 = qa6 ]
then
        sshServer=pgtest@10.142.52.228
else
        echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
ssh -T $sshServer "rm -rf /paytm/NewBuild/*";
validateStep "Newbuild folder cleared";
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/pgproxy-notification/project $sshServer:/paytm/NewBuild/
scp $WORKSPACE/../build-pgproxy-notification/pgproxy-notification/target/pgproxy-notification.war $sshServer:/paytm/NewBuild/
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/pgproxy-notification  $backupPath/pgproxy-notification_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/pgproxy-notification.war $tomcatPath/webapps/pgproxy-notification.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer rm -rf /etc/appconf/project_bckup/project
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi

if [ $1 = qa5 ]
then
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/pgproxy-notification/mock_project $sshServer:/paytm/NewBuild/
ssh -T $sshServer rm -rf /etc/appconf/mock_project_bckup/mock_project
ssh -T $sshServer cp -r /etc/appconf/mock_project  /etc/appconf/mock_project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/mock_project /etc/appconf/
echo "Mock project copied to appconf"
else
echo "Mock project not present"
fi
ssh -T $sshServer sed -i '1iotp.mask.enable=false'  /etc/appconf/project/project-notification.properties
validateStep "otp mask property add"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh                          
