. /paytm/script/new-scripts/commonFunctions.sh
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/requestID/apache-tomcat
backupPath=/paytm/BuildBckup

echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
   sshServer=dev@10.144.18.109
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.111
elif [ $1 = staging ]
then
   sshServer=pgtest@10.142.51.165
elif [ $1 = ite ]
then
   sshServer=pgtest@10.142.51.224
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.51.215
else
    echo Incorrect profile
    exit 1
fi
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
scp -r $WORKSPACE/../build-request-id-service/requestidservice/target/requestidservice.war $sshServer:/paytm/NewBuild/
validateStep "war copy to newbuild";
echo $sshServer
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/requestidservice  $backupPath/requestidservice_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/requestidservice.war $tomcatPath/webapps/requestidservice.war
validateStep "war copy to webapps";
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
                                                                                                                                                                         
