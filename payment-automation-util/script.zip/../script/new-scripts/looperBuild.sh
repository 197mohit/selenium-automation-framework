. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup 

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
   	sshServer=dev@10.144.18.112
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.115
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.155
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.51.225
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.82
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.144
else
    	echo Incorrect profile
	exit 1
fi
ssh -T  $sshServer "rm -rf /paytm/NewBuild/*";
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/looper-service/project $sshServer:/paytm/NewBuild/
validateStep "resources copy to newbuild";
scp -r  $WORKSPACE/../build-looper/looper-service/target/looper-service $sshServer:/paytm/NewBuild/
validateStep "build copy to newbuild";
ssh -T  $sshServer  "ps aux | grep 'looper'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/looper-service  $backupPath/looper_$CurrentTime
ssh -T $sshServer cp -r   /paytm/NewBuild/looper-service /paytm/
validateStep "build copy from newbuild to paytm";
ssh -T $sshServer rm -rf /etc/appconf/project_bckup
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_bckup
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
validateStep "project copy from newbuild to appconf";
nohup ssh -T $sshServer sh /paytm/looper-service/bin/startserver.sh &

