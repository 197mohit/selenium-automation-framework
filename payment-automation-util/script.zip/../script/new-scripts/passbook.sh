. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/passbookService/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
        sshServer=root@10.142.51.62
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.100
elif [ $1 = staging ]
then
        sshServer=pgtest@10.142.51.151
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.51.235
elif [ $1 = qa5 ]
then
        sshServer=pgtest@10.142.51.247 
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/passbook-service/project $sshServer:/paytm/NewBuild/
validateStep "resource copy to newbuild";
scp $WORKSPACE/../build-passbook-service/passbook/target/passbook-service.war $sshServer:/paytm/NewBuild/
validateStep "war copy to newbuild";
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/passbook-service $backupPath/passbook-service_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/passbook-service.war $tomcatPath/webapps/
validateStep "war copy to webapps"
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "appconf folder update"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
