. /paytm/script/new-scripts/commonFunctions.sh
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/subscription/apache-tomcat
backupPath=/paytm/BuildBckup
profileName=$1
WORKSPACE=$2

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
      	sshServer=dev@10.144.18.111
elif [ $1 = hotfix ]
then
 	sshServer=pgtest@10.142.51.99
elif [ $1 = staging ]
then
     	sshServer=pgtest@10.142.51.157
elif [ $1 = ite ]
then
	sshServer=pgtest@10.142.51.200
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.173
elif [ $1 = pos ]
then
        sshServer=pgtest@10.142.52.204
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
ssh -T $sshServer "rm -rf /paytm/NewBuild/*";
validateStep "new build clear"
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/subscription/project $sshServer:/paytm/NewBuild/
echo $sshServer

cd $WORKSPACE;
scp $WORKSPACE/../build-subscription-service/subscription/target/subscription.war $sshServer:/paytm/NewBuild/
validateStep "War copy from target to destination";
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv -f $tomcatPath/webapps/subscription  $backupPath/subscription_$CurrentTime
validateStep "Old build backup"
ssh -T $sshServer cp  /paytm/NewBuild/subscription.war $tomcatPath/webapps/subscription.war
validateStep "war copy to webapps"
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "appconf folder updated"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
