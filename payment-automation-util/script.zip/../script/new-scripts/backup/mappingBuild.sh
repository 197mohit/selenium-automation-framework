. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/mapping-service/apache-tomcat
WORKSPACE=$2
backupPath=/paytm/BuildBckup
echo "tomcat: " $tomcatPath

cd $WORKSPACE/..
if [ $1 = automation ]
then
   sshServer=dev@10.144.18.103
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.102
elif [ $1 = staging ]
then
   sshServer=pgtest@10.142.51.142
elif [ $1 = ite ]
then
   sshServer=pgtest@10.142.52.61
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.51.212
elif [ $1 = pos ]
then
   sshServer=pgtest@10.142.52.142
elif [ $1 = PGP-AccountingPlus-1 ]
then
   sshServer=pgtest@10.142.52.204
else
   echo Incorrect profile
   exit 1
fi
echo "deploying on "$sshServer
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
validateStep "cleared NewBuild"
echo "copying resources to server"
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
scp -r Build-Resources/pgp_$profileName/mapping-service/project $sshServer:/paytm/NewBuild/
scp $WORKSPACE/../build-mapping-service/mapping-service/target/mapping-service.war $sshServer:/paytm/NewBuild/
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/mapping-service  $backupPath/mapping-service_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/mapping-service.war $tomcatPath/webapps/mapping-service.war
validateStep "war copy to webapps";
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "project copy from newbuild to appconf";

if [ $1 = qa5 ]
then
scp -r Build-Resources/pgp_$profileName/mapping-service/mock_project $sshServer:/paytm/NewBuild/
ssh -T $sshServer cp -r /etc/appconf/mock_project  /etc/appconf/mock_project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/mock_project /etc/appconf/
echo "mock project copied to appconf"
else
echo "Mock project is not present."
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh                                                                                                                                                  
