. /paytm/script/new-scripts/commonFunctions.sh 
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = automation ]
then
       	sshServer=dev@10.144.18.115
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.118
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.175
elif [ $1 = ite ]
then 
	sshServer=pgtest@10.142.51.232
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.218
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
ssh -T $sshServer "rm -rf /paytm/NewBuild/*";
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/paymentPostProcessor/project $sshServer:/paytm/NewBuild/
validateStep "project copy to newbuild"
scp -r $WORKSPACE/../build-payment-post-processor/paymentPostProcessor/target/paymentPostProcessor $sshServer:/paytm/NewBuild/payment-postProcessor
validateStep "post processorcopy to newbuild"
ssh -T  $sshServer  "ps aux | grep 'paymentPostProcessor'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/payment-postProcessor  $backupPath/payment-postProcessor_$CurrentTime
validateStep "Build backup"
ssh -T $sshServer cp -r /paytm/NewBuild/payment-postProcessor /paytm/payment-postProcessor
validateStep "post processor copy to paytm"
ssh -T $sshServer rm -rf  /etc/appconf/project_bckup
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_bckup
validateStep "/etc/appconf/project backup"
ssh -T $sshServer mv  /paytm/NewBuild/project /etc/appconf/
validateStep "project copy from newbuild to appconf"
nohup ssh -T $sshServer sh /paytm/payment-postProcessor/bin/startserver.sh &
