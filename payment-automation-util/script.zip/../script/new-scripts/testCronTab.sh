ssh -t pgtest@10.142.51.201 "echo  50 * * * * rm /tmp/test.txt >> /usr/bin/crontab"
