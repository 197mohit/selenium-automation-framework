FileName=$1
echo "copying file $FileName";
array=("10.144.18.101" "10.144.18.102" "10.144.18.103" "10.144.18.107" "10.144.18.105")
#array=(10.144.18.101 10.144.18.102 10.144.18.103)
for i in ${array[*]}
do
echo "copying to ${array[$i]}"
sshpass -p PSand@Box25    scp -r /tmp/$FileName dev@${array[$i]}:/etc/payment_engine/key/test/
done
exit;
. /paytm/script/new-scripts/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/insta/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup
WORKSPACE=$2
source /paytm/script/EnvDetails/$profileName'.sh'
sshServer=$instaServer;
echo "Copying configuration from resources Build-Resources/pgp_$profileName/instaproxy/project"
cd $WORKSPACE
echo "sshserver" $sshServer;
echo "Profile selected:::"$profileName
ssh -T $sshServer "rm -rf /paytm/NewBuild/*"
validateStep "newbuild cleared"
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/instaproxy/project $sshServer:/paytm/NewBuild/
validateStep "copy project folder to NewBuild"
scp $WORKSPACE/../build-insta/instaproxy/target/instaproxy.war $sshServer:/paytm/NewBuild/
validateStep "insta war copy to newbuild"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv  $tomcatPath/webapps/instaproxy  $backupPath/instaproxy_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/instaproxy.war $tomcatPath/webapps/instaproxy.war
validateStep "war copy to webapps"
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
validateStep "projct copy to appconf from newbuild"
if [ $1 = qa5 ]
then
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/instaproxy/mock_project $sshServer:/paytm/NewBuild/
ssh -T $sshServer cp -r /etc/appconf/mock_project  /etc/appconf/mock_project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/mock_project /etc/appconf/
echo "mock_project copy to appconf"
fi

ssh -T $sshServer sh $tomcatPath/bin/startup.sh
sleep 50
echo 'curl https://pgp-'$1'.paytm.in/instaproxy/healthcheck'
curl 'https://pgp-'$1'.paytm.in/instaproxy/healthcheck'
echo 'Health check done'
