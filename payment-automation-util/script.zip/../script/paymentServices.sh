validateStep() {
if [ $? -eq 0 ]; then
    	echo "step $1 successfully completed"
else
    	echo "step $1 failed so, terminating script"
	exit 1
fi
}

profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/paymentService/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
	sshServer=pgtest@10.142.51.70
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.186
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.154
elif [ $1 = qa4 ]
then
   	sshServer=pgtest@10.142.51.231
elif [ $1 = qa5 ]
then
   	sshServer=pgtest@10.142.51.250
else 
	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/payment_services/project $sshServer:/paytm/NewBuild/
validateStep "copy resources"
cd $WORKSPACE; mvn clean install  -DskipTests=true  -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi

scp $WORKSPACE/target/*.war $sshServer:/paytm/NewBuild/

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/pgplus-paymentservices  $backupPath/pgplus-paymentservices_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/pgplus-paymentservices.war $tomcatPath/webapps/
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer rsync --remove-source-files -zvh /etc/appconf/project/  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
