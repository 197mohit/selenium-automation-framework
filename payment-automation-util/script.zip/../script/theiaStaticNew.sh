#!/bin/bash
. ./commonFunctions.sh

CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/lighttpd
backupPath=/paytm/BuildBckup
sshServer=$2
WORKSPACE=$1
staticFolder=1.2
BuildFolderName=theia_static

echo "profile: " $profile
echo "backup path: " $backupPath
echo "tomcat path: " $tomcatPath
echo "workspace: " $WORKSPACE
echo "server: " $sshServer

cd  $WORKSPACE/static;
tar -cvf static.tar *
scp -r $WORKSPACE/static/static.tar $sshServer:/paytm/NewBuild/$BuildFolderName/
validateStep "scp static tar"
ssh -T $sshServer cp -r  $tomcatPath/$staticFolder  $backupPath/$BuildFolderName$CurrentTime
validateStep "backup static folder"
#ssh -T $sshServer rm -rf $tomcatPath/$staticFolder/*
#ssh -T $sshServer cp  /paytm/NewBuild/$BuildFolderName/static.tar  $tomcatPath/$staticFolder/
ssh -T $sshServer sh /paytm/script/extractStatic.sh $staticFolder $BuildFolderName
validateStep "extract static tar"
