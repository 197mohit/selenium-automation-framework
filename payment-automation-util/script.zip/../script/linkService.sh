. /paytm/script/commonFunctions.sh
profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/linkService/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
        sshServer=root@10.142.51.88
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.89
elif [ $1 = staging ]
then
	sshServer=pgtest@10.142.51.139
elif [ $1 = qa4 ]
then
   	sshServer=pgtest@10.142.51.220
elif [ $1 = qa5 ]
then
   	sshServer=pgtest@10.142.51.243
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/link/project $sshServer:/paytm/NewBuild/

cd $WORKSPACE;
mvn clean install  -DskipTests -e
validateStep "build project"
scp -r $WORKSPACE/payment-link/target/link.war $sshServer:/paytm/NewBuild/
validateStep "war to Newbuild"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/link  $backupPath/link_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/link.war $tomcatPath/webapps/link.war
validateStep "war copy to destination"
ssh -T $sshServer rm -rf /etc/appconf/project_bckup/*
ssh -T $sshServer cp -r /etc/appconf/project /etc/appconf/project_bckup
ssh -T $sshServer rm -rf /etc/appconf/project
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf
validateStep "appconf property copy"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
