validateStep() {
if [ $? -eq 0 ]; then
        echo "Step - $1 : SUCCESS"
else
        echo "Step - $1 : FAILED => ABORTING"
        exit 1
fi
}

profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/pgpplusbo/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
    	sshServer=dev@10.144.18.106
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.112
elif [ $1 = staging ]
then
   	sshServer=pgtest@10.142.51.174
elif [ $1 = qa4 ]
then
	sshServer=pgtest@10.142.51.213
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.214
else
    	echo Incorrect profile
	exit 1
fi

scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/pg-plus-bo/project $sshServer:/paytm/NewBuild/
validateStep "scp resources"

cd $WORKSPACE; mvn clean install  -DskipTests -U -P$profileName -e
validateStep "build project"

scp $WORKSPACE/pg-plus-bo/target/pg-plus-bo.war $sshServer:/paytm/NewBuild/
validateStep "scp war"

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"

ssh -T $sshServer mv $tomcatPath/webapps/pg-plus-bo  $backupPath/pg-plus-bo_$CurrentTime
validateStep "backup project"

ssh -T $sshServer cp  /paytm/NewBuild/pg-plus-bo.war $tomcatPath/webapps/pg-plus-bo.war
validateStep "war copy to webapps"

ssh -T $sshServer rm -rf  /etc/appconf/project_bckup
ssh -T $sshServer "mv /etc/appconf/project  /etc/appconf/project_bckup"
ssh -T $sshServer rm -rf  /etc/appconf/project
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf
validateStep "copy updated project properties"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
