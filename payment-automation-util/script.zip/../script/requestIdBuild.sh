CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/requestID/apache-tomcat
backupPath=/paytm/BuildBckup

echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
   sshServer=dev@10.144.18.109
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.111
elif [ $1 = staging ]
then
   sshServer=pgtest@10.142.51.165
elif [ $1 = qa4 ]
then
   sshServer=pgtest@10.142.51.224
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.51.215
else
    echo Incorrect profile
    exit 1
fi

cd $WORKSPACE;
mvn clean install  -DskipTests -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit;
fi
scp -r $WORKSPACE/requestidservice/target/requestidservice.war $sshServer:/paytm/NewBuild/

echo $sshServer
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/requestidservice  $backupPath/requestidservice_$CurrentTime
if [ $? -eq 0 ]; then
    echo "old build backup done"
else
    echo "old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/requestidservice.war $tomcatPath/webapps/requestidservice.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
                                                                                                                                                                         
