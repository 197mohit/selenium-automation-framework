profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm
echo $tomcatPath
backupPath=/paytm/BuildBckup
if [ $1 = automation ]
then
    sshServer=dev@10.144.18.109
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.112
elif [ $1 = integration ]
then
   profileName=automation
   sshServer=pgtest@10.142.51.112
else
    echo Incorrect profile
fi
echo Select server is $sshServer
WORKSPACE=$2
cd $WORKSPACE;

mvn clean install  -DskipTests -P$profileName -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit;
fi
scp -r $WORKSPACE/bo-consumer/target/bo-consumer $sshServer:/paytm/NewBuild/
echo $sshServer
ssh -T $sshServer  "ps aux | grep 'bo-consumer'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/bo-consumer  $backupPath/bo-consumer_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp -r /paytm/NewBuild/bo-consumer $tomcatPath
if [ $? -eq 0 ]; then
    echo "folder copy to webapps success"
else
    echo "folder copy to webapps  fail"
fi
ssh -T $sshServer sh $tomcatPath/bo-consumer/bin/start-server.sh
