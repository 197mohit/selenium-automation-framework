sshServer=10.142.51.172
ssh -T $sshServer mkdir 
