CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup
sshServer=dev@10.144.18.112
echo $sshServer
ssh -T  $sshServer  "ps aux | grep 'looper'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer cp -r /paytm/looper-service  $backupPath/looper_$CurrentTime
if [ $? -eq 0 ]; then
    echo "backup done"
else
    echo "backup fail"
fi
ssh -T $sshServer cp -r /paytm/NewBuild/looper-service /paytm/
if [ $? -eq 0 ]; then
    echo "folder copy to  paytm success"
else
    echo "folder copy to paytm  fail"
fi
ssh -T $sshServer ps -ef | grep java
nohup ssh -T $sshServer sh /paytm/looper-service/bin/startserver.sh &
echo "looper started "
sleep 20
ssh -T $sshServer  "ps aux | grep 'looper'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer cp -r /propertyBck/resources/* /paytm/looper-service/resources/
if [ $? -eq 0 ]; then
    echo "property backup  success"
else     
    echo "property backup   fail"
fi

nohup ssh -T $sshServer sh /paytm/looper-service/bin/startserver.sh &

