if [ $1 = automation ]
then
  array=("dev@10.144.18.101" "dev@10.144.18.102" "dev@10.144.18.103" "dev@10.144.18.107" "dev@10.144.18.105")
elif [ $1 = hotfix ]
then
  array=(pgtest@10.142.51.122 pgtest@10.142.52.106 pgtest@10.142.51.102 pgtest@10.142.51.103 pgtest@10.142.51.119)
elif [ $1 = staging ]
then
   array=(pgtest@10.142.51.135 pgtest@10.142.51.164 pgtest@10.142.51.142 pgtest@10.142.51.148 pgtest10.142.51.147)
elif [ $1 = ite ]
then 
   array=(pgtest@10.142.51.201 pgtest@10.142.51.172 pgtest@10.142.52.61 pgtest@10.142.51.210 pgtest@10.142.51.207)
elif [ $1 = qa5 ]
then 
   array=(pgtest@10.142.52.41 pgtest@10.142.51.203 pgtest@10.142.51.212 pgtest@10.142.51.216 pgtest@10.142.51.208)
else
    echo Incorrect profile
fi
module=(theia insta mapping-service pgproxy_notification merchant-status )
for i in ${!array[*]}
do
echo ${array[$i]}
echo ${module[$i]}
sshServer=${array[$i]}
moduleName=${module[$i]}
echo $Old $New
tomcatPath=/paytm/$moduleName/apache-tomcat/
echo $tomcatPath
ssh -T $sshServer sed -i -e 's/ifcsupergw.'$Old'.dl.alipaydev.com/ifcsupergw.'$New'.dl.alipaydev.com/' /etc/appconf/project/facade.properties
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
done
