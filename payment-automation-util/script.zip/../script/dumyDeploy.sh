profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/insta/apache-tomcat/webapps/instaproxy/WEB-INF/lib
echo $tomcatPath
formatterPath=/paytm/mockFormatter

if [ $1 = automation ]
then
   sshServer=dev@10.144.18.102
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.52.106
elif [ $1 = staging ]
then
   sshServer=pgtest@10.142.51.164
elif [ $1 = qa4 ]
then
   sshServer=pgtest@10.142.51.172
elif [ $1 = qa5 ]
then 
   sshServer=pgtest@10.142.51.203
else
    echo Incorrect profile
fi

echo "ssh server: " $sshServer
scp $formatterPath/dummyhdfc.jar $sshServer:$tomcatPath
if [ $? -eq 0 ]; then
    echo "formatter jar copy to destination folder successful"
else
    echo "formatter jar copy to destination folder failed"
    exit 1;
fi
#ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
#ssh -T $sshServer sh $tomcatPath/bin/startup.sh       
#sleep 30
echo 'curl https://pgp-'$1'.paytm.in/instaproxy/healthcheck'
curl 'https://pgp-'$1'.paytm.in/instaproxy/healthcheck'                                                                                                                                                                               
