profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/merchant-passbook/apache-tomcat
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
    	sshServer=root@10.142.51.79
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.110
elif [ $1 = staging ]
then
        sshServer=pgtest@10.142.51.136
elif [ $1 = qa4 ]
then
	sshServer=pgtest@10.142.51.244
elif [ $1 = qa5 ]
then
	sshServer=pgtest@10.142.51.238
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/merchant-passbook/project $sshServer:/paytm/NewBuild/

cd $WORKSPACE;
mvn clean install -DskipTests -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi

scp $WORKSPACE/merchant-passbook/target/merchant-passbook.war $sshServer:/paytm/NewBuild/
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/merchant-passbook $backupPath/merchant-passbook_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/merchant-passbook.war $tomcatPath/webapps/
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi

ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
