#!/bin/bash

export oldServiceURL="http://10.142.0.109:18080";
export newServiceURL="http://10.142.0.124:18080";
export walletWebURL="http://10.142.0.104:18080";
export redisURL="10.142.0.127";
export merchantURL="http://10.142.0.119:18080";
export walletAdminURL="http://10.142.0.112:18080";
export oldesURL="10.142.0.135:9300";
export esURL="10.142.0.138:9300,10.142.0.138:9200";
export kafkaZookeeperURL="10.142.0.132:2181";
export kafkaBrokerURL="10.142.0.132:9092";
export authURL="https://accounts-staging.paytm.in";
export authAdminPass="paytm@197";
export umpURL="https://wallet-staging.paytm.in";
export logLocation="alog";
export cassandraURL="10.142.0.147";
