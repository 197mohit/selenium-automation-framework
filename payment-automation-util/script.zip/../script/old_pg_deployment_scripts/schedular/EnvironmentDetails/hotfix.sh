#!/bin/bash

export oldServiceURL="http://10.142.0.108:18080";
echo $oldServiceURL
export newServiceURL="http://10.142.0.123:18080";

export walletWebURL="http://10.142.51.92:18080";

export redisURL="10.142.51.92";
echo $redisURL
export merchantURL="http://10.142.51.121:18081";

export walletAdminURL="http://10.142.0.112:18080";

export oldesURL="10.142.0.135:9300";
echo $oldesURL
export esURL="10.142.51.120:9300,10.142.51.120:9200";
echo $esURL
export kafkaZookeeperURL="10.142.51.92:2181";
echo $kafkaZookeeperURL
export kafkaBrokerURL="10.142.51.92:9092";
echo $kafkaBrokerURL
export authURL="https://accounts-staging.paytm.in";
echo $authURL
export authAdminPass="paytm@197";
echo $authAdminPass
export umpURL="https://wallet-staging.paytm.in";
echo $umpURL
export logLocation="alog";
echo $logLocation
export cassandraURL="10.142.51.120";
