#!/bin/bash
cd wallet-web/WebContent/WEB-INF

rowNum=` grep -n "com.paytm.wallet.web.filters.InputHMACFilter" web.xml |cut -f1 -d:`
startRow="$(($rowNum-3))"
endRow="$(($rowNum+6))"
sed -i $startRow' s/^/<!--/' web.xml
sed -i $endRow' s/$/-->/' web.xml

rowNum=` grep -n "com.paytm.wallet.web.filters.MerchantAuthHMACFilter" web.xml |cut -f1 -d:`
startRow="$(($rowNum-3))"
endRow="$(($rowNum+6))"
sed -i $startRow' s/^/<!--/' web.xml
sed -i $endRow' s/$/-->/' web.xml


rowNum=` grep -n "com.paytm.wallet.web.filters.MerchantAuthV2HmacFilter" web.xml |cut -f1 -d:`
startRow="$(($rowNum-3))"
endRow="$(($rowNum+9))"
sed -i $startRow' s/^/<!--/' web.xml
sed -i $endRow' s/$/-->/' web.xml

cd ../../../
