#!/bin/bash
cd $1/service-common/profiles/test92

sed -i -e 's/elasticsearch.data.serverPort=10.0.3.246:9302/elasticsearch.data.serverPort='"$oldesURL"'/' config.properties

sed -i -e 's/cassandra.contactpoints=localhost/cassandra.contactpoints='"$cassandraURL"'/' config.properties

sed -i -e 's/log4j.path=\/tmp\/service.log/log4j.path=\/alog\/service.log/' config.properties

sed -i -e 's/log4j.appender=CONSOLE/log4j.appender=ROLLINGFILE/' config.properties

sed -i -e 's/log4j.request.appender=ROLL/log4j.request.appender=ROLLINGFILE/' config.properties

sed -i -e 's/log4j.oauth.appender=ROLL/log4j.oauth.appender=ROLLINGFILE/' config.properties

sed -i -e 's/oauthCommLogFilePath=\/tmp\/oauth.log/oauthCommLogFilePath=\/alog\/oauth.log/' config.properties

sed -i -e 's/requestLogFilePath=\/tmp\/request.log/requestLogFilePath=\/alog\/request.log/' config.properties

cd ../../../
