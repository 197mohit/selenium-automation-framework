#!/bin/bash

sed -i -e 's?10.0.3.244:2181?'"$kafkaZookeeperURL"'?g' wallet-jobs/wallet-service-consumer/profiles/qa/config.properties

sed -i -e 's?elastic.str.primary.size=5?elastic.str.primary.size=1?g' wallet-jobs/wallet-service-consumer/profiles/qa/config.properties

sed -i -e 's?elastic.str.secondary.size=3?elastic.str.secondary.size=1?g' wallet-jobs/wallet-service-consumer/profiles/qa/config.properties
