#!/bin/bash

cd wallet-jobs/wallet-service-consumer/src/main/resources/

sed -i -e 's?cassandra.mth.primary.size=250?cassandra.mth.primary.size=1?g' kafka-consumer.properties

sed -i -e 's?elastic.mth.primary.size=250?elastic.mth.primary.size=1?g' kafka-consumer.properties

sed -i -e 's?elastic.str.primary.size=50?elastic.str.primary.size=1?g' kafka-consumer.properties

sed -i -e 's?elastic.str.secondary.size=30?elastic.str.secondary.size=1?g' kafka-consumer.properties

sed -i -e 's?cassandra.str.primary.size=50?cassandra.str.primary.size=1?g' kafka-consumer.properties

sed -i -e 's?cassandra.str.secondary.size=30?cassandra.str.secondary.size=1?g' kafka-consumer.properties

cd ../../../../../
