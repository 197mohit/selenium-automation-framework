#!/bin/bash

sed -i -e 's?10.0.3.245?'"$cassandraURL"'?g' wallet-utils/profiles/qa/config.properties

sed -i -e 's?localhost:9300?'"$esURL"'?g' wallet-utils/profiles/qa/config.properties
