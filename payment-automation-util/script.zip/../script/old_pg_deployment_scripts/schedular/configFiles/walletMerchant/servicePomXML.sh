#!/bin/bash
cd merchant-panel/

sed -i '/<\/plugins>/ i <plugin> \ <groupId>org.apache.maven.plugins</groupId> \ <artifactId>maven-surefire-plugin</artifactId> \ <version>2.4.2</version> \ <configuration> \ <skipTests>true</skipTests> \ </configuration> \ </plugin> \ <plugin> \ <groupId>org.jacoco</groupId> \ <artifactId>jacoco-maven-plugin</artifactId> \ <version>0.7.5.201505241946</version> \ <executions> \ <execution><id>pre-unit-test</id><goals><goal>prepare-agent</goal> \ </goals> \ <configuration> \ <destFile>${project.build.directory}/coverage-reports/jacoco-ut.exec</destFile><propertyName>surefireArgLine</propertyName> \ </configuration> \ </execution> \ <execution><id>post-unit-test</id><phase>test</phase><goals><goal>report</goal></goals><configuration> \ <dataFile>${project.build.directory}/coverage-reports/jacoco-ut.exec</dataFile> \ <outputDirectory>${project.reporting.outputDirectory}/jacoco-ut</outputDirectory></configuration> \ </execution> \ </executions> \ </plugin>'  pom.xml

cd ../
