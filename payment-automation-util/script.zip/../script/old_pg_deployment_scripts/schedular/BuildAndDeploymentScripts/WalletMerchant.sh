#!/bin/bash

sh /usr/buildFiles/configFiles/WalletMerchant/walletCommonPomXML.sh
sh /usr/buildFiles/configFiles/WalletMerchant/servicePomXML.sh

mvn clean compile install -DskipTests -Ptest92

echo "Build proceduce completed"

if [ $DeployWalletMerchant = true ];then
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
mkdir -p /usr/RunSetup/war/newWar;
mkdir -p /usr/RunSetup/war/backupWar;
HERE

sshpass -p $ServerPassword scp merchant-panel/target/wallet-merchant.war $ServerUser@$HostIp:/usr/RunSetup/war/newWar

echo "File copied to other server"

CurrentTime=`date +"%m-%d-%Y-%N"`
echo "Current time is $CurrentTime"

pid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep tomcat |awk '{print $2}'`
echo "Tomcat is running with PID: $pid"
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
echo "Killing $pid"
kill -9 $pid

mv /usr/local/tomcat/webapps/wallet-merchant.war /usr/RunSetup/war/backupWar/wallet-merchant.war.$CurrentTime
echo "war backup taken successfully."
rm -rf /usr/local/tomcat/webapps/wallet-merchant*
mv /usr/RunSetup/war/newWar/wallet-merchant.war /usr/local/tomcat/webapps/wallet-merchant.war
echo "starting server"
cd /usr/local/tomcat/bin
sh startup.sh
HERE

echo "Starting the automation server. Please wait"

sleep 200
pid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep tomcat |awk '{print $2}'`

echo "Server started with PID $pid."
fi
