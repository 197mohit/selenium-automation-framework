#!/bin/bash

sh /usr/buildFiles/configFiles/NewService/consumerConfigProperties.sh
sh /usr/buildFiles/configFiles/NewService/utilConfigProperties.sh
sh /usr/buildFiles/configFiles/NewService/walletAPIPomXML.sh
sh /usr/buildFiles/configFiles/NewService/kafkaConfigProperties.sh

echo "Starting Build creation"
./build-all.sh qa
echo "Build proceduce completed"

if [ $DeployNewService = true ]; then
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
mkdir -p /usr/RunSetup/war/newWar;
mkdir -p /usr/RunSetup/war/backupWar;
HERE
sshpass -p $ServerPassword scp wallet-api/read-api/target/service.war $ServerUser@$HostIp:/usr/RunSetup/war/newWar
fi

if [ $DeployNewServiceConsumer = true ]; then
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
mkdir -p /usr/RunSetup/service-consumer/new;
mkdir -p /usr/RunSetup/service-consumer/backup;
mkdir -p /usr/local/paytm/service-consumer;
HERE
sshpass -p $ServerPassword scp wallet-jobs/wallet-service-consumer/target/wallet-service-consumer.jar $ServerUser@$HostIp:/usr/RunSetup/service-consumer/new
sshpass -p $ServerPassword scp -r wallet-jobs/wallet-service-consumer/target/lib $ServerUser@$HostIp:/usr/RunSetup/service-consumer/new
fi
echo "File copied to other server"


CurrentTime=`date +"%m-%d-%Y-%N"`
echo "Current time is $CurrentTime"

if [ $DeployNewService = true ]; then
pid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep tomcat |awk '{print $2}'`
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
echo "Killing $pid"
kill -9 $pid

mv /usr/local/tomcat8/webapps/service.war /usr/RunSetup/war/backupWar/service.war.$CurrentTime
echo "war backup taken successfully."
rm -rf /usr/local/tomcat8/webapps/service*
mv /usr/RunSetup/war/newWar/service.war /usr/local/tomcat8/webapps/service.war
echo "starting server"
cd /usr/local/tomcat8/bin
sh startup.sh
HERE
fi

if [ $DeployNewServiceConsumer = true ]; then
consumerpid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep wallet-service-consumer.jar |awk '{print $2}'`
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
echo "Killing consumer $consumerpid"
kill -9 $consumerpid

mv /usr/local/paytm/service-consumer/wallet-service-consumer.jar /usr/RunSetup/service-consumer/backup/wallet-service-consumer.jar.$CurrentTime
mv /usr/local/paytm/service-consumer/lib /usr/RunSetup/service-consumer/backup/lib.$CurrentTime
mv /usr/RunSetup/service-consumer/new/wallet-service-consumer.jar /usr/local/paytm/service-consumer/wallet-service-consumer.jar
mv /usr/RunSetup/service-consumer/new/lib /usr/local/paytm/service-consumer/lib
echo "starting consumer"
cd /usr/local/paytm/service-consumer
java -jar wallet-service-consumer.jar </dev/null &>/dev/null &
HERE
fi

echo "Starting the automation server. Please wait"

sleep 100

if [ $DeployNewService = true ]; then
pid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep tomcat |awk '{print $2}'`
echo "Server started with PID $pid."
fi

if [ $DeployNewServiceConsumer = true ]; then
consumerpid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep wallet-service-consumer.jar |awk '{print $2}'`
echo "Server started with PID $consumerpid."
fi
