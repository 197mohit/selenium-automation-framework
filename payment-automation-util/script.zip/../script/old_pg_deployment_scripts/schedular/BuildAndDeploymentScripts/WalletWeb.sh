#!/bin/bash

cd paytm-wallet/
echo $authURL;
sh /usr/buildFiles/configFiles/WalletWeb/walletWebPomXML.sh
sh /usr/buildFiles/configFiles/WalletWeb/walletCommonPomXML.sh

if [ $HmacFilterOff = true ]; then
sh /usr/buildFiles/configFiles/WalletWeb/walletWebXML.sh
fi

mvn clean compile install -DskipTests -Dmaven.compiler.source=1.8 -Dmaven.compiler.target=1.8 -Ptest92

echo "Build proceduce completed"

if [ $DeployWalletWeb = true ];then
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
mkdir -p /usr/RunSetup/war/newWar;
mkdir -p /usr/RunSetup/war/backupWar;
HERE
sshpass -p $ServerPassword scp wallet-web/target/wallet-web-1.0-SNAPSHOT.war $ServerUser@$HostIp:/usr/RunSetup/war/newWar/
fi

if [ $DeployMessageQueue = true ]; then
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
mkdir -p /usr/RunSetup/MessageQueue/new;
mkdir -p /usr/RunSetup/MessageQueue/backup;
mkdir -p /usr/local/paytm/wallet-message-queue;
HERE
sshpass -p $ServerPassword scp wallet-message-queue/target/wallet-message-queue-1.0-SNAPSHOT.jar $ServerUser@$HostIp:/usr/RunSetup/MessageQueue/new/
sshpass -p $ServerPassword scp -r wallet-message-queue/target/lib $ServerUser@$HostIp:/usr/RunSetup/MessageQueue/new/
fi

if [ $DeployScheduler = true ]; then
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
mkdir -p /usr/RunSetup/Scheduler/new;
mkdir -p /usr/RunSetup/Scheduler/backup;
mkdir -p /usr/local/paytm/wallet-scheduler;
HERE
sshpass -p $ServerPassword scp wallet-scheduler/target/wallet-scheduler-1.0-SNAPSHOT.jar $ServerUser@$HostIp:/usr/RunSetup/Scheduler/new/
sshpass -p $ServerPassword scp -r wallet-scheduler/target/lib $ServerUser@$HostIp:/usr/RunSetup/Scheduler/new/
fi

echo "File copied to other server"

CurrentTime=`date +"%m-%d-%Y-%N"`
echo "Current time is $CurrentTime"

if [ $DeployWalletWeb = true ];then
pid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep tomcat |awk '{print $2}'`
echo "Tomcat is running with PID: $pid"
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
echo "Process ID is $pid"
echo "Killing $pid"
kill -9 $pid

mv /usr/local/tomcat/webapps/wallet-web.war /usr/RunSetup/war/backupWar/wallet-web.war.$CurrentTime
rm -rf /usr/local/tomcat/webapps/wallet-web*
cp /usr/RunSetup/war/newWar/wallet-web-1.0-SNAPSHOT.war /usr/local/tomcat/webapps/wallet-web.war
echo "starting server"
cd /usr/local/tomcat/bin
sh startup.sh
HERE
fi


if [ $DeployScheduler = true ]; then
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
mv /usr/local/paytm/wallet-scheduler/wallet-scheduler-1.0-SNAPSHOT.jar /usr/RunSetup/Scheduler/backup/wallet-scheduler-1.0-SNAPSHOT.jar.$CurrentTime
mv /usr/local/paytm/wallet-scheduler/lib /usr/RunSetup/Scheduler/backup/lib.$CurrentTime
cp /usr/RunSetup/Scheduler/new/wallet-scheduler-1.0-SNAPSHOT.jar /usr/local/paytm/wallet-scheduler/wallet-scheduler-1.0-SNAPSHOT.jar
cp -r /usr/RunSetup/Scheduler/new/lib /usr/local/paytm/wallet-scheduler/
HERE
fi

if [ $DeployMessageQueue = true ]; then
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
mv /usr/local/paytm/wallet-message-queue/wallet-message-queue-1.0-SNAPSHOT.jar /usr/RunSetup/Scheduler/backup/wallet-scheduler-1.0-SNAPSHOT.jar.$CurrentTime
mv /usr/local/paytm/wallet-message-queue/lib /usr/RunSetup/Scheduler/backup/lib.$CurrentTime
cp /usr/RunSetup/MessageQueue/new/wallet-message-queue-1.0-SNAPSHOT.jar /usr/local/paytm/wallet-message-queue/wallet-message-queue-1.0-SNAPSHOT.jar
cp -r /usr/RunSetup/MessageQueue/new/lib /usr/local/paytm/wallet-message-queue
HERE
fi

echo "Server startup in progress, please wait"

if [ $DeployWalletWeb = true ];then
sleep 200
pid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep tomcat |awk '{print $2}'`
echo "Server started with PID $pid."
fi
