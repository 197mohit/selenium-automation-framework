#!/bin/bash
sh /usr/buildFiles/configFiles/OldService/servicePomXML.sh
sh /usr/buildFiles/configFiles/OldService/serviceCommonConfig.sh

mvn clean compile install -DskipTests -Ptest92

echo "Build proceduce completed"

if [ $DeployOldService = true ];then
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
mkdir -p /usr/RunSetup/war/newWar;
mkdir -p /usr/RunSetup/war/backupWar;
HERE

sshpass -p $ServerPassword scp service/target/service-0.0.1-SNAPSHOT.war $ServerUser@$HostIp:/usr/RunSetup/war/newWar

echo "File copied to other server"

CurrentTime=`date +"%m-%d-%Y-%N"`
echo "Current time is $CurrentTime"

pid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep tomcat |awk '{print $2}'`
echo "Tomcat is running with PID: $pid"
sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp <<HERE
echo "Process ID is $pid"
echo "Killing $pid"
kill -9 $pid

mv /usr/local/tomcat/webapps/service.war /usr/RunSetup/war/backupWar/service.war.$CurrentTime
echo "war backup taken successfully."
rm -rf /usr/local/tomcat/webapps/service*
cp /usr/RunSetup/war/newWar/service-0.0.1-SNAPSHOT.war /usr/local/tomcat/webapps/service.war
echo "starting server"
cd /usr/local/tomcat/bin
sh startup.sh
HERE

echo "Starting the staging server. Please wait"

sleep 200
pid=` sshpass -p $ServerPassword ssh -T $ServerUser@$HostIp ps -ef |grep tomcat |awk '{print $2}'`

echo "Server started with PID $pid."
fi
