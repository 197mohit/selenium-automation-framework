profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
WORKSPACE=$2
backupPath=/paytm/BuildBckup 
echo "value of"$1
if [ $1 = automation ]
then
	profileName=auto
    	sshServer=dev@10.144.18.112
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.115
	cd $WORKSPACE
elif [ $1 = staging ]
then
   	profileName=staging
   	sshServer=pgtest@10.142.51.190
elif [ $1 = qa4 ]
then
	profileName=qa4
	sshServer=pgtest@10.142.51.225
elif [ $1 = qa5 ]
then
	profileName=qa5
	sshServer=pgtest@10.142.51.82
else
    echo Incorrect profile
fi
echo $sshServer

cd $WORKSPACE;
mvn clean install  -DskipTests  -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi
exit
scp -r  $WORKSPACE/looper-service/target/looper-service $sshServer:/paytm/NewBuild/

ssh -T  $sshServer  "ps aux | grep 'looper'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/looper-service  $backupPath/looper_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer mv  /paytm/NewBuild/looper-service /paytm/
if [ $? -eq 0 ]; then
    echo "folder copy to  paytm success"
else
    echo "folder copy to paytm  fail"
fi
ssh -T $sshServer rm -rf /etc/appconf/project_bckup
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_bckup
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updated successfully"
fi
nohup ssh -T $sshServer sh /paytm/looper-service/bin/startserver.sh &
echo "looper started "
