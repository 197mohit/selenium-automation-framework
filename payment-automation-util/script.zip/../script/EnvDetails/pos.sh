export theiaServer=pgtest@10.142.52.185;

export instaServer=pgtest@10.142.52.145;

export mappingServer=pgtest@10.142.52.142;
export secTheiaServer=;
export lighttpd=pgtest=;
export boPanel=pgtest=@10.142.52.197;
export producersServer=pgtest@10.142.52.160;
export pgProxyNotifactionServer=pgtest@10.142.52.139;

export refundServer=pgtest@10.142.52.155;

export merchantStatucServer=;

export pgPlusBoServer=pgtest@10.142.52.152;

export promoServer=;

export savedCardServer=pgtest@10.142.52.136;

export subscriptionServer=pgtest@10.142.52.148;

export looperServer=;

export walletWebServer=;

export walletMerchantServer=;

export postProcessorServer=;

export adminServer=pgtest@10.142.52.136;

export communicationServer=pgtest@10.142.52.199;

export queueHandlerServer=pgtest@10.142.52.176;

export mappingServiceMigrationConsumerServer=pgtest@10.142.52.151;

export mappingServiceUpdateConsumerServer=pgtest@10.142.52.74
export velocityServer=;

export linkServer=;
export merchantPassbookServer=;
export passbookServer=;

export scanpayServer=pgtest;

export paymentServiceServer=;
export DBServerIp=10.142.51.242;
export DBSeverUser=pgalipay
export DBServerPass=pgal1p@y;

