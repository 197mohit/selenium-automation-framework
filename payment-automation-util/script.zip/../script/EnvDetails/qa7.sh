export theiaServer=pgtest@10.142.53.123;
export instaServer=pgtest@10.142.52.214;
export lighttpd=pgtest@10.142.51.239; 
export mappingServer=pgtest@10.142.52.236;

export pgProxyNotifactionServer=pgtest@10.142.53.110;

export refundServer=pgtest@10.142.52.215;

export merchantStatucServer=pgtest@10.142.52.221;

export pgPlusBoServer=pgtest@10.142.53.128;

export promoServer=pgtest@10.142.52.244;

export adminServer=pgtest@10.142.53.110;

export producersServer=pgtest@10.142.52.129;

export queueHandlerServer=pgtest@10.142.52.218;

export mappingConsumerServer=pgtest@10.142.52.236;

export paymentServiceServer=root@10.142.52.240;
export DBServerIp=10.142.52.226;
export DBSeverUser=accqa7;
export DBServerPass=accqa7;
