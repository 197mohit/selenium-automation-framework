export theiaServer=dev@10.144.18.101;
export secTheiaServer=dev@10.144.18.119
export instaServer=dev@10.144.18.102;
export lighttpd=dev@10.144.18.121	
export mappingServer=dev@10.144.18.102;

export pgProxyNotifactionServer=dev@10.144.18.107;

export refundServer=dev@10.144.18.104;

export merchantStatucServer=dev@10.144.18.105;

export pgPlusBoServer=dev@10.144.18.106;

export promoServer=dev@10.144.18.108;

export savedCardServer=dev@10.144.18.110;

export subscriptionServer=dev@10.144.18.111;

export looperServer=dev@10.144.18.112;

export walletWebServer=dev@10.144.18.114;

export walletMerchantServer=dev@10.144.18.113;

export postProcessorServer=dev@10.144.18.115;

export adminServer=dev@10.144.18.116;

export producersServer=dev@10.144.18.116

export communicationServer=dev@10.144.18.117;

export queueHandlerServer=dev@10.144.18.118;

export mappingConsumerServer=dev@10.144.18.119;

export velocityServer=root@10.142.51.91;

export linkServer=root@10.142.51.88;

export merchantPassbookServer=root@10.142.51.79;
export passbookServer=root@10.142.51.62;

export scanpayServer=root@10.142.51.80;

export paymentServiceServer=root@10.142.51.70;
export DBServerIp=10.144.18.122;
export DBSeverUser=pgalipay
export DBServerPass=pgal1p@y;
