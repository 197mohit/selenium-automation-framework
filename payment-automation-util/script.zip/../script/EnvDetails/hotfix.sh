export theiaServer=pgtest@10.142.51.122;

export instaServer=pgtest@10.142.52.106;

export mappingServer=pgtest@10.142.51.102;

export boPanel=pgtest@10.142.51.76;
export pgProxyNotifactionServer=pgtest@10.142.51.103;

export refundServer=pgtest@10.142.51.113;

export merchantStatusServer=pgtest@10.142.51.119;

export pgPlusBoServer=pgtest@10.142.51.112;

export promoServer=pgtest@10.142.51.106;

export requestIdServer=pgtest@10.142.51.111;

export savedCardServer=pgtest@10.142.51.192;

export subscriptionServer=pgtest@10.142.51.99;

export looperServer=pgtest@10.142.51.115;

export postProcessorServer=pgtest@10.142.51.118;

export adminServer=pgtest@10.142.51.193;

export producersServer=pgtest@10.142.51.104

export communicationServer=pgtest@10.142.51.124;

export queueHandlerServer=pgtest@10.142.51.117;

export mappingConsumerServer=pgtest@10.142.51.119;

export velocityServer=pgtest@10.142.51.105;

export linkServer=pgtest@10.142.51.89;

export merchantPassbookServer=pgtest@10.142.51.110;

export passbookServer=pgtest@10.142.51.100;

export scanpayServer=pgtest@10.142.51.101;

export paymentServiceServer=pgtest@10.142.51.186;
export walletWebServer=pgtest@10.142.51.92;

export walletMerchantServer=pgtest@10.142.51.121;
export theiaStaticServer=pgtest@10.142.51.87
export secTheiaServer=pgtest@10.142.51.122;
export lighttpd=pgtest@10.142.51.87;

export DBServerIp=10.142.51.123;
export DBSeverUser=pgalipay
export DBServerPass=pgal1p@y;
