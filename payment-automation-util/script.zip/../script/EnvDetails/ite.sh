#export theiaServer=pgtest@10.142.52.38;
export theiaServer=pgtest@10.142.51.201;
export instaServer=pgtest@10.142.51.172;
export secTheiaServer=pgtest@10.142.51.201
export lighttpd=pgtest@10.142.51.239
export mappingServer=pgtest@10.142.51.205;
export boPanel=pgtest@10.142.52.25;
export producersServer=10.142.52.29;
export pgProxyNotifactionServer=pgtest@10.142.51.210;

export refundServer=pgtest@10.142.51.206;

export merchantStatucServer=pgtest@10.142.51.207;

export pgPlusBoServer=pgtest@10.142.51.213;

export promoServer=pgtest@10.142.51.222;

export savedCardServer=pgtest@10.142.51.217;

export subscriptionServer=pgtest@10.142.51.200;

export looperServer=pgtest@10.142.51.225;

export walletWebServer=;

export walletMerchantServer=;

export postProcessorServer=pgtest@10.142.51.232;

export adminServer=pgtest@10.142.52.31;



export communicationServer=pgtest@10.142.51.230;

export queueHandlerServer=pgtest@10.142.51.234;

export mappingConsumerServer=pgtest@10.142.52.120;

export velocityServer=pgtest@10.142.52.33;

export linkServer=pgtest@10.142.51.220;
export merchantPassbookServer=pgtest@10.142.51.244;
export passbookServer=pgtest@10.142.51.235;

export scanpayServer=pgtest@10.142.51.246;

export paymentServiceServer=pgtest@10.142.51.231;
export DBServerIp=10.142.51.242;
export DBSeverUser=pgalipay
export DBServerPass=pgal1p@y;
export billproxyServer=pgtest@10.142.53.49
