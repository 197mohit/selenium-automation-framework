export theiaServer=pgtest@10.142.51.135;
export secTheiaServer=;
export instaServer=pgtest@10.142.51.164;

export mappingServer=pgtest@10.142.51.142;

export producersServer=pgtest@10.142.51.166;

export lighttpd=pgtest@10.142.51.165;
export boPanel=;
export pgProxyNotifactionServer=pgtest@10.142.51.148;

export refundServer=pgtest@10.142.51.162;

export merchantStatucServer=pgtest@10.142.51.147;

export pgPlusBoServer=pgtest@10.142.51.174;

export promoServer=pgtest@10.142.51.150;

export savedCardServer=pgtest@10.142.51.146;

export subscriptionServer=pgtest@10.142.51.157;

export looperServer=pgtest@10.142.51.155;

export walletWebServer=;

export walletMerchantServer=;

export postProcessorServer=pgtest@10.142.51.175;

export adminServer=pgtest@10.142.51.128;

export communicationServer=pgtest@10.142.51.159;

export queueHandlerServer=pgtest@10.142.52.115;

export mappingConsumerServer=pgtest@10.142.51.158;

export velocityServer=pgtest@10.142.51.152;

export linkServer=pgtest@10.142.51.139;
export merchantPassbookServer=pgtest@10.142.51.136;
export passbookServer=pgtest@10.142.51.151;

export scanpayServer=pgtest@10.142.51.160;

export paymentServiceServer=pgtest@10.142.51.154;
