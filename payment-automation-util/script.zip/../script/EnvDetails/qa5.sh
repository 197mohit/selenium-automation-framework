export theiaServer=pgtest@10.142.52.41;

export instaServer=pgtest@10.142.51.203;

export mappingServer=pgtest@10.142.51.212;
export secTheiaServer=pgtest@10.142.52.41
export lighttpd=pgtest@10.142.51.236;
export boPanel=pgtest@10.142.52.47;
export producersServer=pgtest@10.142.52.26;
export pgProxyNotifactionServer=pgtest@10.142.51.216;

export refundServer=pgtest@10.142.51.184;

export merchantStatucServer=pgtest@10.142.51.208;

export pgPlusBoServer=pgtest@10.142.51.214;

export promoServer=pgtest@10.142.51.221;

export savedCardServer=pgtest@10.142.51.245;

export subscriptionServer=pgtest@10.142.51.173;

export looperServer=pgtest@10.142.51.82;

export walletWebServer=;

export walletMerchantServer=;

export postProcessorServer=pgtest@10.142.51.218;

export adminServer=pgtest@10.142.52.32;

export communicationServer=pgtest@10.142.51.228;

export queueHandlerServer=pgtest@10.142.51.240;

export mappingConsumerServer=pgtest@10.142.52.35;

export velocityServer=pgtest@10.142.52.28;

export linkServer=pgtest@110.142.51.243;
export merchantPassbookServer=pgtest@10.142.51.238;
export passbookServer=pgtest@10.142.51.247;

export scanpayServer=pgtest@10.142.51.226;

export paymentServiceServer=pgtest@10.142.51.250;
export DBServerIp=10.142.51.253;
export DBSeverUser=pgalipay
export DBServerPass=pgal1p@y;
