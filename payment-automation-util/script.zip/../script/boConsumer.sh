profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
WORKSPACE=$2
backupPath=/paytm/BuildBckup 
echo "value of"$1
if [ $1 = automation ]
then
	profileName=auto
    	sshServer=dev@10.144.18.106
	cd $WORKSPACE
        cd ..
        scp -r Build-Resources/pgp_$profileName/bo-consumer/project/ $sshServer:/paytm/NewBuild/
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.112
	cd $WORKSPACE
	cd ..
	scp -r Build-Resources/pgp_$profileName/bo-consumer/project/ $sshServer:/paytm/NewBuild/
elif [ $1 = staging ]
then
   	profileName=staging
   	sshServer=pgtest@10.142.51.174
	cd $WORKSPACE
        cd ..
        scp -r Build-Resources/pgp_$profileName/bo-consumer/project/ $sshServer:/paytm/NewBuild/
elif [ $1 = qa4 ]
then
	profileName=qa4
	sshServer=pgtest@10.142.51.213
	cd $WORKSPACE
        cd ..
	scp -r Build-Resources/pgp_$profileName/bo-consumer/project/ $sshServer:/paytm/NewBuild/
elif [ $1 = qa5 ]
then
	profileName=qa5
	sshServer=pgtest@10.142.51.82
	cd $WORKSPACE
        cd ..
	scp -r Build-Resources/pgp_$profileName/bo-consumer/project/ $sshServer:/paytm/NewBuild/
else
    echo Incorrect profile
fi
echo $sshServer

cd $WORKSPACE;
mvn clean install  -DskipTests -P$profileName -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit;
fi

scp -r  $WORKSPACE/bo-consumer/target/bo-consumer $sshServer:/paytm/NewBuild/

ssh -T  $sshServer  "ps aux | grep 'bo-consumer'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/bo-consumer/bo-consumer  $backupPath/bo-consumer_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer mv  "/paytm/NewBuild/bo-consumer /paytm/bo-consumer/"
if [ $? -eq 0 ]; then
    echo "folder copy to  paytm success"
else
    echo "folder copy to paytm  fail"
fi
ssh -T $sshServer rm -rf /etc/appconf/project_bckup
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_bckup
ssh -T $sshServer cp -r  /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updated successfully"
fi
nohup ssh -T $sshServer sh /paytm/bo-consumer/bo-consumer/bin/start-server.sh &&
echo "looper started "
