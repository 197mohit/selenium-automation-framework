#!/bin/bash
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/tomcat_merchant
echo $tomcatPath
backupPath=/paytm
if [ $1 = automation ]
then
    sshHost=dev@10.144.18.113
    sh /paytm/script/wallet/editMerchantPom.sh
elif [ $1 = hotfix ]
then
   sshHost=pgtest@10.142.51.121
   sh /paytm/script/wallet/editMerchantPomHotfix.sh
else
    echo Incorrect profile
fi
echo selected server is $sshHost
WORKSPACE=$2
cd $WORKSPACE;
mvn clean install -DskipTests -Ptest92
scp $WORKSPACE/merchant-panel/target/wallet-merchant.war $sshHost:/paytm/NewBuild
ssh -T $sshHost  "ps aux | grep 'tomcat_merchant'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshHost  mv $tomcatPath/webapps/wallet-merchant  $backupPath/BuildBckup/wallet-merchant_$CurrentTime
ssh -T $sshHost cp  $backupPath/NewBuild/wallet-merchant.war $tomcatPath/webapps/wallet-merchant.war
ssh -T $sshHost sh $tomcatPath/bin/startup.sh
echo "tomcat started"
sleep 15
ssh -T $sshHost  "ps aux | grep 'tomcat_merchant'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshHost "sh /paytm/script/change_log_fileLocation.sh"
ssh -T $sshHost sh $tomcatPath/bin/startup.sh
      
