#!/bin/bash
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/tomcat_web
echo $tomcatPath
backupPath=/paytm
if [ $1 = automation ]
then
    sshHost=dev@10.144.18.114
    sh /home/suresh_18193/paytm/script/wallet/editWalletPom.sh
elif [ $1 = hotfix ]
then
   sshHost=pgtest@10.142.51.92
   sh /home/suresh_18193/paytm/script/wallet/editWalletPomHotfix.sh
else
    echo Incorrect profile
fi
echo selected server is  $sshHost
WORKSPACE=$2
cd $WORKSPACE/paytm-wallet;
mvn clean install -DskipTests -Ptest92
exit
scp $WORKSPACE/paytm-wallet/wallet-web/target/wallet-web-1.0-SNAPSHOT.war $sshHost:/paytm/NewBuild
ssh -T $sshHost  "ps aux | grep 'tomcat_web'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshHost  mv $tomcatPath/webapps/wallet-web  $backupPath/BuildBckup/wallet-web_$CurrentTime
ssh -T $sshHost cp  $backupPath/NewBuild/wallet-web-1.0-SNAPSHOT.war $tomcatPath/webapps/wallet-web.war
ssh -T $sshHost sh $tomcatPath/bin/startup.sh
echo "tomcat started"
sleep 15
ssh -T $sshHost  "ps aux | grep 'tomcat_web'| grep -v grep|awk '{print \$2}' | xargs kill -9"
#ssh -T $sshHost "sh /paytm/script/edit_WebXml_ForHMAC.sh"
ssh -T $sshHost cp /paytm/BuildBckup/web.xml /paytm/tomcat_web/webapps/wallet-web/WEB-INF/web.xml
ssh -T $sshHost sh $tomcatPath/bin/startup.sh 
