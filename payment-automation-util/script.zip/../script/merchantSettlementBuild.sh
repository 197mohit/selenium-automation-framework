CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/tomcat-mercSettlement
echo $tomcatPath
backupPath=/paytm/BuildBckup
if [ $1 = automation ]
then
        confFolder=pgp-auto
        sshServer=root@10.142.
elif [ $1 = hotfix ]
then
   confFolder=pgp-hotfix
   sshServer=pgtest@10.142.51.180
else
    echo Incorrect profile
fi
echo Select server is $sshServer
WORKSPACE=$2
cd $WORKSPACE;
mvn clean install  -DskipTests -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit;
fi
scp -r $WORKSPACE/conf/$confFolder/project $sshServer:/paytm/NewBuild/
scp $WORKSPACE/merchant-settlement-service/target/merchant-settlement-service.war $sshServer:/paytm/NewBuild/

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/merchant-settlement-service $backupPath/merchant-settlement-service_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/merchant-settlement-service.war $tomcatPath/webapps/merchant-settlement-service.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh-T $sshServer sh $tomcatPath/bin/startup.sh
