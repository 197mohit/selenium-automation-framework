CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/theia/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup
WORKSPACE=$1
profileName=$2
sshServer=$3
echo $WORKSPACE ">>>" $profileName ">>>>>>" $sshServer

echo "Copying configuration from resources /Build-Resources/pgp_$profileName/theia/project"
cd $WORKSPACE/..
if [ $profileName = auto ];
then
  scp -r Build-Resources/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
elif [ $profileName = hotfix ];
then
  scp -r Build-Resources/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
elif [ $profileName = staging ];
then
  scp -r Build-Resources/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
elif [ $profileName = qa4 ]
then
  scp -r Build-Resources/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
elif [ $profileName = qa5 ]
then
  scp -r Build-Resources/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
else
  echo "Incorrect profile name"
fi

scp $WORKSPACE/theia/target/theia.war $sshServer:/paytm/NewBuild/

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer "mv $tomcatPath/webapps/theia  $backupPath/theia_$CurrentTime"
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/theia.war $tomcatPath/webapps/theia.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer mv "/etc/appconf/project/*  /etc/appconf/project_bckup"
ssh -T $sshServer rm -rf /etc/appconf/project/
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
