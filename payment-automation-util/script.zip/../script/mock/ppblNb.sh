validateStep()
{
if [ $? -eq 0 ]; then
        echo "[STEP] : $1 : SUCCESS"
else
        echo "[STEP] : $1 : FAILED => ABORTING"
        exit 1
fi

}

mockPpblUrl=payments.bank.base.url\=https://pgp-automation.paytm.in/mockbank
oriPpblUrl=payments.bank.base.url\=https://secure-ite2.paytmbank.com
cd /etc/appconf/project
if [ $1 = apply ]
then
        sed -i -e  '/payments.bank.base.url=/c\'$mockPpblUrl facade.properties
elif [ $1 = remove ]
then
        sed -i -e '/payments.bank.base.url=/c\'$oriPpblUrl facade.properties
else
        echo "incorect request"
fi
ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print $2}' | xargs kill -9
sh /paytm/theia/apache-tomcat/bin/startup.sh
validateStep "Tomcat start"
