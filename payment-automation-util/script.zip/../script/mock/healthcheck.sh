#while [ $status == fail]
healthcheck()
{
for i in 1 2 3 4 5
do
	echo curl 'https://pgp-'$1'.paytm.in/instaproxy/healthcheck'
	response=`curl 'https://pgp-'$1'.paytm.in/instaproxy/healthcheck'`
	if [ $response = SUCCESS ];
	then
		echo "response: "$response
		echo "healthcheck done" 
		exit
	fi
	sleep 5
done
}	
