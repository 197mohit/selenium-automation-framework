#. /paytm/script/commonFunction.sh
. /paytm/healthcheck.sh
validateStep()
{
if [ $? -eq 0 ]; then
        echo "[STEP] : $1 : SUCCESS"
else
        echo "[STEP] : $1 : FAILED => ABORTING"
        exit 1
fi
	
}
mockEnrolledAuth=cc.enrolled.authentication.url\=https:\/\/pgp-automation.paytm.in\/mockbank\/bankFormatter\/hdfcFormatter\/Payment
mockRefundUrl=hdfc.refund.url\=https:\/\/pgp-automation.paytm.in\/mockbank\/pgwayd\/servlet\/TranPortalXMLServlet
mockEnrollmentUrl=cc.enrollment.url\=https:\/\/pgp-automation.paytm.in\/mockbank\/bankFormatter\/hdfcFormatter\/verification
orignEnrollmentUrl=cc.enrollment.url\=https:\/\/securepayments.fssnet.co.in\/hdfcbanka\/servlet\/MPIVerifyEnrollmentXMLServlet
orignEnrolledAuth=cc.enrolled.authentication.url\=https:\/\/securepayments.fssnet.co.in\/hdfcbanka\/servlet\/MPIPayerAuthenticationXMLServlet
orignRefundUrl=hdfc.refund.url\=https:\/\/securepayments.fssnet.co.in\/hdfcbanka\/servlet\/TranPortalXMLServlet
cd /paytm;
rm -r  /paytm/mockExtraction;
mkdir mockExtraction;
cd /paytm/insta/apache-tomcat/webapps/instaproxy/WEB-INF/lib/
hdfcJar=`ls | grep 'hdfc'| awk -F 'hdfc-formatter-' '{print \$2}'|tail -1`
echo hdfc-formatter$hdfcJar
hdfcJarName=hdfc-formatter-$hdfcJar
echo hdfc jar name $hdfcJarName
cp '/paytm/insta/apache-tomcat/webapps/instaproxy/WEB-INF/lib/'$hdfcJarName /paytm/mockExtraction
cd /paytm/mockExtraction;
jar -xvf hdfc-formatter-$hdfcJar;
rm hdfc-formatter-$hdfcJar;
if [ $1 = apply ]
then 
	sed -i -e '/cc.enrolled.authentication.url/c\'$mockEnrolledAuth hdfcresources.properties
	sed -i -e '/hdfc.refund.url/c\'$mockRefundUrl hdfcresources.properties
	sed -i -e '/cc.enrollment.url/c\'$mockEnrollmentUrl hdfcresources.properties
elif [ $1 = remove ]
then 
	sed -i -e '/cc.enrolled.authentication.url/c\'$orignEnrolledAuth hdfcresources.properties
	sed -i -e '/hdfc.refund.url/c\'$orignRefundUrl hdfcresources.properties
	sed -i -e '/cc.enrollment.url/c\'$orignEnrollmentUrl hdfcresources.properties
else
	echo "incorect request"
fi
jar -cvf  hdfc-formatter-$hdfcJar *;
validateStep "formatter jar creation"
cp hdfc-formatter-$hdfcJar /paytm/insta/apache-tomcat/webapps/instaproxy/WEB-INF/lib/
ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print $2}' | xargs kill -9
sh /paytm/insta/apache-tomcat/bin/startup.sh
validateStep "Tomcat start"
sleep 60
InstaPid=`ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print $2}'`
echo "Insta PID: "$InstaPid
#echo 'curl https://pgp-'$2'.paytm.in/instaproxy/healthcheck'
#curl 'https://pgp-'$2'.paytm.in/instaproxy/healthcheck'
healthcheck $2
