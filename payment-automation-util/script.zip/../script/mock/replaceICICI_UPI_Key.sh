. /paytm/script/new-scripts/commonFunctions.sh
. /paytm/script/mock/healthcheck.sh
Operation=$1;
Env=$2;
echo /paytm/script/EnvDetails/$Env.sh
source /paytm/script/EnvDetails/$Env.sh
echo $Operation mock on $Env;
echo ssh -T $instaServer "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
 ssh -T $instaServer "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
#validateStep " Insta killed"
if [ $1 = apply ]
then
	ssh -T $instaServer "cp /paytm/ICICI_UPI_KEY/mock/* /etc/payment_engine/conf/icici/"; 
elif [ $1 = remove ]
then
	ssh -T $instaServer "cp /paytm/ICICI_UPI_KEY/orig/* /etc/payment_engine/conf/icici/";
else
        echo "incorect request"
fi
ssh -T $instaServer sh /paytm/insta/apache-tomcat/bin/startup.sh
validateStep "Tomcat start"
sleep 60
healthcheck $2
