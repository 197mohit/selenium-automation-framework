. /paytm/script/commonFunctions.sh
echo $2 
echo /paytm/script/EnvDetails/$2.sh
source /paytm/script/EnvDetails/$2.sh
validateStep "Environment details load"
echo "server deatils "$theiaServer
ssh -T $theiaServer "rm /paytm/script/ppblNb.sh"
scp /paytm/script/mock/ppblNb.sh $theiaServer:/paytm/script/
validateStep "scp ppblNb.sh to "$theiaServer
ssh -T $theiaServer "sh /paytm/script/ppblNb.sh $1 $2"
