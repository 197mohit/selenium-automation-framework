test=hello
test2=world-$test
echo $test2
