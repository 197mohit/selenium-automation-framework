. /paytm/script/commonFunctions.sh
echo $2 
echo /paytm/script/EnvDetails/$2.sh
source /paytm/script/EnvDetails/$2.sh
validateStep "Environment details load"
echo "server deatils"$instaServer
ssh -T $instaServer "rm /paytm/hdfc.sh"
scp /paytm/script/mock/hdfc.sh $instaServer:/paytm
scp /paytm/script/mock/healthcheck.sh  $instaServer:/paytm
validateStep "Scp hdfc.sh to "$instaServer
ssh -T $instaServer "sh /paytm/hdfc.sh $1 $2"
