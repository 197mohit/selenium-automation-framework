profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/refundService/apache-tomcat
backupPath=/paytm/BuildBckup
WORKSPACE=$2

echo "profile: " $profileName
echo "tomcat path: " $tomcatPath
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

cd $WORKSPACE/..

if [ $1 = auto ]
then
   sshServer=dev@10.144.18.104
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.113
elif [ $1 = staging ]
then
   sshServer=pgtest@10.142.51.162
elif [ $1 = qa4 ]
then 
   sshServer=pgtest@10.142.51.206
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.51.184
else
   echo Incorrect profile
   exit 1
fi

echo "copying resources to server: " $sshServer
scp -r Build-Resources/pgp_$profileName/refund/project $sshServer:/paytm/NewBuild/

cd $WORKSPACE;
mvn clean install  -DskipTests -P$profileName -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi

scp $WORKSPACE/refund/target/refund.war $sshServer:/paytm/NewBuild/

echo $sshServer
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv  $tomcatPath/webapps/refund  $backupPath/refund_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp /paytm/NewBuild/refund.war $tomcatPath/webapps/refund.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer 'rm -rf /etc/appconf/project_bckup/*'
ssh -T $sshServer 'mv  /etc/appconf/project/*  /etc/appconf/project_bckup'
ssh -T $sshServer 'cp -r /paytm/NewBuild/project /etc/appconf/'
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
