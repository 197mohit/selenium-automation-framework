. /paytm/script/commonFunctions.sh
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup

if [ $1 = automation ]
then
        sshServer=dev@10.144.18.106
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.93
elif [ $1 = qa4 ]
then
   sshServer=pgtest@10.142.52.31
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.52.32
else
    echo Incorrect profile
    exit 1
fi
echo $sshServer
WORKSPACE=$2
cd $WORKSPACE;
scp $WORKSPACE/admin-panel/admin/target/admin.war  $sshServer:/paytm/NewBuild/
validateStep "war copy to destination SUCCESS"
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer cp -r $tomcatPath/webapps/admin  $backupPath/admin_$CurrentTime
ssh -T $sshServer cp  /paytm/NewBuild/admin.war $tomcatPath/webapps/admin.war
validateStep "copy admin war to tomcat "
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
sleep 15
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
scp -r $WORKSPACE/../Build-Resources/pgp_$1/admin-panel/* $sshServer:$tomcatPath/webapps/admin/WEB-INF/classes/alipay
validateStep "scp resources to /paytm/update-consumer/resources/qa"
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
validateStep "Tomcat started"
