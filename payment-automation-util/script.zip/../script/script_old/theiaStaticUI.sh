CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/lighttpd
echo $tomcatPath
backupPath=/paytm/BuildBckup
if [ $1 = automation ]
then
    sshServer=dev@10.144.18.121
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.87
else
    echo Incorrect profile
fi
echo $sshServer
WORKSPACE=$2
cd  $WORKSPACE/static;
tar -cvf static.tar *
staticFolder=1.4
BuildFolderName=theia_static_UI
scp -r $WORKSPACE/static/static.tar $sshServer:/paytm/NewBuild/$BuildFolderName/
ssh -T $sshServer cp -r $tomcatPath/$staticFolder  $backupPath/$BuildFolderName$CurrentTime
if [ $? -eq 0 ]; then
    echo "backup done"
else
    echo "backup fail"
fi
ssh -T $sshServer rm -rf $tomcatPath/$staticFolder/*
ssh -T $sshServer cp  /paytm/NewBuild/$BuildFolderName/static.tar  $tomcatPath/$staticFolder/
if [ $? -eq 0 ]; then
    echo "theia static copied"
else
    echo "theia static not copied"
fi
ssh -T $sshServer sh /paytm/script/extractStatic.sh $staticFolder $BuildFolderName
if [ $? -eq 0 ]; then
    echo "tar extracted"
else
    echo "tar extraction failed"
fi
