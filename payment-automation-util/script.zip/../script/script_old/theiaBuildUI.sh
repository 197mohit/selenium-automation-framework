CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/theia/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup
if [ $1 = 'automation' ]
then
    sshServer=dev@10.144.18.119
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.209
else
    echo Incorrect profile
fi
echo $sshServer
WORKSPACE=$2
cd $WORKSPACE;
mvn clean install  -DskipTests -P$1 -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit;
fi
scp -r $WORKSPACE/conf/theia/pgp-automation/project $sshServer:/paytm/NewBuild/
scp $WORKSPACE/theia/target/theia.war $sshServer:/paytm/NewBuild/
ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/theia  $backupPath/theia_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/theia.war $tomcatPath/webapps/theia.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi
ssh -T $sshServer sed -i -e 's/static.version=1.2/static.version=1.4/g' /etc/appconf/project/project-theia.properties;
ssh -T $sshServer sed -i -e  's/https:\/\/pgp-automation.paytm.in\/theia/http:\/\/10.144.18.119:8080\/theia/' /etc/appconf/project/project-theia.properties;
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
