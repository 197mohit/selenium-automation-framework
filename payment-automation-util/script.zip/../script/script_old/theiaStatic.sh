CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/lighttpd
echo $tomcatPath
backupPath=/paytm/BuildBckup
if [ $1 = automation ]
then
    sshServer=dev@10.144.18.121
elif [ $1 = hotfix ]
then
   sshServer=pgtest@10.142.51.87
elif [ $1 = integration ]
then
   sshServer=pgtest@10.142.51.165
else
    echo Incorrect profile
fi
echo $sshServer
WORKSPACE=$2
cd $WORKSPACE;
mvn clean install  -DskipTests -P$1 -e
cd  $WORKSPACE/static;
tar -cvf static.tar *
staticFolder=1.2
BuildFolderName=theia_static
scp -r $WORKSPACE/static/static.tar $sshServer:/paytm/NewBuild/$BuildFolderName/
ssh -T $sshServer cp -r  $tomcatPath/$staticFolder  $backupPath/$BuildFolderName$CurrentTime
if [ $? -eq 0 ]; then
    echo "backup done"
else
    echo "backup fail"
fi
#ssh -T $sshServer rm -rf $tomcatPath/$staticFolder/*
#ssh -T $sshServer cp  /paytm/NewBuild/$BuildFolderName/static.tar  $tomcatPath/$staticFolder/
ssh -T $sshServer sh /paytm/script/extractStatic.sh $staticFolder $BuildFolderName
if [ $? -eq 0 ]; then
    echo "extraction done"
else
    echo "extraction failed"
fi
