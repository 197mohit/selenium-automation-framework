profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/theia/apache-tomcat
echo $tomcatPath
backupPath=/paytm/BuildBckup
if [ $1 = automation ]
then
  sshServer=dev@10.144.18.101

elif [ $1 = hotfix ]
then
  sshServer=pgtest@10.142.51.122
elif [ $1 = integration ]
then
   profileName=automation
   sshServer=pgtest@10.142.51.135
elif [ $1 = qa4 ]
then
   sshServer=pgtest@10.142.51.201
elif [ $1 = qa5 ]
then
   sshServer=pgtest@10.142.51.198   

else
    echo Incorrect profile
fi

echo Select server is $sshServer
WORKSPACE=$2
cd $WORKSPACE;

mvn clean install  -DskipTests -P$profileName -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit;
fi

if [ $1 = automation ];
then
  scp -r $WORKSPACE/Build-Resources/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
  echo "Copying configuration from resources $WORKSPACE/Build-Resources/pgp_$profileName/theia/project"
elif [ $1 = hotfix ];
then
  scp -r $WORKSPACE/Build-Resources/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
  echo "Copying configuration from resources $WORKSPACE/Build-Resources/pgp_$profileName/theia/project"
elif [ $1 = integration ];
then
  scp -r $WORKSPACE/Build-Resources/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
  echo "Copying configuration from resources $WORKSPACE/Build-Resources/pgp_$profileName/theia/project"
else
  scp -r /paytm/conf/pgp_$profileName/theia/project $sshServer:/paytm/NewBuild/
  echo "Copying configuration from /paytm/conf/pgp_$profileName/theia"
fi

scp $WORKSPACE/theia/target/theia.war $sshServer:/paytm/NewBuild/

ssh -T $sshServer  "ps aux | grep 'apache-tomcat'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshServer mv $tomcatPath/webapps/theia  $backupPath/theia_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer cp  /paytm/NewBuild/theia.war $tomcatPath/webapps/theia.war
if [ $? -eq 0 ]; then
    echo "war copy to webapps success"
else
    echo "war copy to webapps  fail"
fi
ssh -T $sshServer cp -r /etc/appconf/project  /etc/appconf/project_bckup
ssh -T $sshServer cp -r /paytm/NewBuild/project /etc/appconf/
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updation failed."
fi
ssh -T $sshServer sh $tomcatPath/bin/startup.sh
