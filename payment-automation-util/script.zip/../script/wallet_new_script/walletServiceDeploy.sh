#!/bin/bash
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/tomcat_service
echo $tomcatPath
backupPath=/paytm
if [ $1 = automation ]
then
    sshHost=dev@10.144.18.113
    source /paytm/script/wallet_new_script/EnvironmentDetails/automation.sh
    sh /paytm/script/wallet_new_script/configFiles/oldService/servicePomXML.sh $2
   sh /paytm/script/wallet_new_script/configFiles/oldService/serviceCommonConfig.sh $2
elif [ $1 = hotfix ]
then
   sshHost=pgtest@10.142.51.121
   source /paytm/script/wallet_new_script/EnvironmentDetails/hotfix.sh
   sh /paytm/script/wallet_new_script/configFiles/oldService/servicePomXML.sh $2   
   sh /paytm/script/wallet_new_script/configFiles/oldService/serviceCommonConfig.sh $2
else
    echo Incorrect profile
fi
echo selected server is $sshHost
WORKSPACE=$2
cd $WORKSPACE;
mvn clean install -DskipTests -Ptest92
scp $WORKSPACE/merchant-panel/target/wallet-merchant.war $sshHost:/paytm/NewBuild
ssh -T $sshHost  "ps aux | grep 'tomcat_merchant'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshHost  mv $tomcatPath/webapps/wallet-merchant  $backupPath/BuildBckup/wallet-merchant_$CurrentTime
ssh -T $sshHost cp  $backupPath/NewBuild/wallet-merchant.war $tomcatPath/webapps/wallet-merchant.war
ssh -T $sshHost sh $tomcatPath/bin/startup.sh
echo "tomcat started"
sleep 15
ssh -T $sshHost  "ps aux | grep 'tomcat_merchant'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshHost "sh /paytm/script/change_log_fileLocation.sh"
ssh -T $sshHost sh $tomcatPath/bin/startup.sh
      
