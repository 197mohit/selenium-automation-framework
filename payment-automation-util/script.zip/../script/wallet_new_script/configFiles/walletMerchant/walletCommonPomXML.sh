#!/bin/bash
pwd;
cd $1/merchant-common/;
echo "location where pom stored"$2"/merchant-common/"
sed -i -e 's?http://125.63.68.113?'"$authURL"'?g' pom.xml

sed -i -e 's?<wallet.web.service_base_url>http://10.0.3.243:18080/wallet-web</wallet.web.service_base_url>?<wallet.web.service_base_url>'"$walletWebURL"'/wallet-web</wallet.web.service_base_url>?g' pom.xml

sed -i -e 's?<redis.serverHost.qr.code>localhost</redis.serverHost.qr.code>?<redis.serverHost.qr.code>'"$redisURL"'</redis.serverHost.qr.code>?g' pom.xml

sed -i -e 's?<redis.serverHost>localhost</redis.serverHost>?<redis.serverHost>'"$redisURL"'</redis.serverHost>?g' pom.xml

sed -i -e 's?<redis.message.queue.host>localhost</redis.message.queue.host>?<redis.message.queue.host>'"$redisURL"'</redis.message.queue.host>?g' pom.xml

sed -i -e 's?<merchant.base.url>http://10.0.3.119:7777/wallet-merchant</merchant.base.url>?<merchant.base.url>'"$merchantURL"'/wallet-merchant</merchant.base.url>?g' pom.xml

sed -i -e 's?<walletAdmin.base.url>http://10.0.3.119:9999/wallet-admin</walletAdmin.base.url>?<walletAdmin.base.url>'"$walletAdminURL"'/wallet-admin</walletAdmin.base.url>?g' pom.xml

sed -i -e 's?<elasticsearch.data.serverPort>127.0.0.1:9300,127.0.0.1:9302</elasticsearch.data.serverPort>?<elasticsearch.data.serverPort>'"$oldesURL"'</elasticsearch.data.serverPort>?g' pom.xml

sed -i -e 's?<kafka.zookepers>localhost:2181,localhost:2182,localhost:2183</kafka.zookepers>?<kafka.zookepers>'"$kafkaZookeeperURL"'</kafka.zookepers>?g' pom.xml

sed -i -e 's?<kafka.brokers>localhost:9092,localhost:9093</kafka.brokers>?<kafka.brokers>'"$kafkaBrokerURL"'</kafka.brokers>?g' pom.xml

sed -i -e 's?<cassandra.contactpoints>localhost</cassandra.contactpoints>?<cassandra.contactpoints>'"$cassandraURL"'</cassandra.contactpoints>?g' pom.xml

sed -i -e 's?<ump.mayassar.api.url>http://staging-dashboard.paytm.com/api/v1/context</ump.mayassar.api.url>?<ump.mayassar.api.url>'"$umpURL"'/api/v1/context</ump.mayassar.api.url>?g' pom.xml


cd ../
