#!/bin/bash
pwd;
echo $authURL;
cd $1/paytm-wallet/wallet-common/;
echo "editing pom at location"$2"/paytm-wallet/wallet-common"
sed -i -e 's?kyc-staging.paytm.com?'"$authURL"'?g' pom.xml
<alipay.signature.toggle>1</alipay.signature.toggle>
sed -i -e 's?<alipay.signature.toggle>1<alipay.signature.toggle>?<alipay.signature.toggle>0<alipay.signature.toggle>?g' pom.xml
sed -i -e 's?http://10.0.3.14?'"$authURL"'?g' pom.xml

sed -i -e 's?https://10.0.3.14?'"$authURL"'?g' pom.xml
sed -i -e 's?<mapping.service.url>http:\/\/52.76.10.37</mapping.service.url>?<mapping.service.url>'"$mappingURL"'</mapping.service.url>?g' pom.xml
sed -i -e 's?<auth.admin.pass>one97</auth.admin.pass>?<auth.admin.pass>'"$authAdminPass"'</auth.admin.pass>?g' pom.xml

sed -i -e 's?<wallet.service_base_url>http://10.0.3.245:18080/service</wallet.service_base_url>?<wallet.service_base_url>'"$oldServiceURL"'/service</wallet.service_base_url>?g' pom.xml

sed -i -e 's?<wallet.new_service_base_url>http://10.0.3.245:18080/service</wallet.new_service_base_url>?<wallet.new_service_base_url>'"$newServiceURL"'/service</wallet.new_service_base_url>?g' pom.xml

sed -i -e 's?<wallet.web.service_base_url>http://10.0.3.245:18080/wallet-web</wallet.web.service_base_url>?<wallet.web.service_base_url>'"$walletWebURL"'/wallet-web</wallet.web.service_base_url>?g' pom.xml

sed -i -e 's?<wallet.web.soap.service_base_url>http://10.0.3.245:18080/wallet-web</wallet.web.soap.service_base_url>?<wallet.web.soap.service_base_url>'"$walletWebURL"'/wallet-web</wallet.web.soap.service_base_url>?g' pom.xml

sed -i -e 's?<redis.serverHost>localhost</redis.serverHost>?<redis.serverHost>'"$redisURL"'</redis.serverHost>?g' pom.xml

sed -i -e 's?<balances.redis.serverHost>localhost</balances.redis.serverHost>?<balances.redis.serverHost>'"$redisURL"'</balances.redis.serverHost>?g' pom.xml

sed -i -e 's?<qr.code.redis.serverHost>localhost</qr.code.redis.serverHost>?<qr.code.redis.serverHost>'"$redisURL"'</qr.code.redis.serverHost>?g' pom.xml

sed -i -e 's?<p2p.ftu.redis.serverHost>localhost</p2p.ftu.redis.serverHost>?<p2p.ftu.redis.serverHost>'"$redisURL"'</p2p.ftu.redis.serverHost>?g' pom.xml

sed -i -e 's?<redis.message.queue.host>localhost</redis.message.queue.host>?<redis.message.queue.host>'"$redisURL"'</redis.message.queue.host>?g' pom.xml

sed -i -e 's?<merchant.base.url>http://10.0.3.119:7777/wallet-merchant</merchant.base.url>?<merchant.base.url>'"$merchantURL"'/wallet-merchant</merchant.base.url>?g' pom.xml

sed -i -e 's?<walletAdmin.base.url>http://10.0.3.119:9999/wallet-admin</walletAdmin.base.url>?<walletAdmin.base.url>'"$walletAdminURL"'/wallet-admin</walletAdmin.base.url>?g' pom.xml

sed -i -e 's?<walletAdmin.origin.url>http://10.0.3.119:9999</walletAdmin.origin.url>?<walletAdmin.origin.url>'"$walletAdminURL"'</walletAdmin.origin.url>?g' pom.xml

sed -i -e 's?<elasticsearch.data.serverPort>10.0.3.245:9300,10.0.3.245:9302</elasticsearch.data.serverPort>?<elasticsearch.data.serverPort>'"$esURL"'</elasticsearch.data.serverPort>?g' pom.xml

sed -i -e 's?<kafka.zookepers>10.0.3.244:2181</kafka.zookepers>?<kafka.zookepers>'"$kafkaZookeeperURL"'</kafka.zookepers>?g' pom.xml

sed -i -e 's?<kafka.brokers>10.0.3.244:9092</kafka.brokers>?<kafka.brokers>'"$kafkaBrokerURL"'</kafka.brokers>?g' pom.xml

sed -i -e 's?<ump.mayassar.api.url>http://staging-dashboard.paytm.com/api/v1/context</ump.mayassar.api.url>?<ump.mayassar.api.url>'"$umpURL"'/api/v1/context</ump.mayassar.api.url>?g' pom.xml

sed -i -e 's?<ump.base.url>https://staging-dashboard.paytm.com</ump.base.url>?<ump.base.url>'"$umpURL"'</ump.base.url>?g' pom.xml

cd ../
