#!/bin/bash
cd $1/paytm-wallet/wallet-web/

sed -i -e 's?<log4j.path>/tmp/wallet-web.log</log4j.path>?<log4j.path>/'"$logLocation"'/wallet-web.log</log4j.path>?g' pom.xml

sed -i -e 's?<log4j.appender>ROLL</log4j.appender>?<log4j.appender>ROLLINGFILE</log4j.appender>?g' pom.xml

cd ../
