#!/bin/bash
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/tomcat_web
echo $tomcatPath
backupPath=/paytm
if [ $1 = automation ]
then
    sshHost=dev@10.144.18.114
    source /paytm/script/wallet_new_script/EnvironmentDetails/automation.sh
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletCommonPomXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebPomXML.sh $2
elif [ $1 = hotfix ]
then
   sshHost=pgtest@10.142.51.92
    source /paytm/script/wallet_new_script/EnvironmentDetails/hotfix.sh
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletCommonPomXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebPomXML.sh $2
else
    echo Incorrect profile
fi
echo selected server is  $sshHost
WORKSPACE=$2
cd $WORKSPACE/paytm-wallet;
mvn clean install -DskipTests -Ptest92
