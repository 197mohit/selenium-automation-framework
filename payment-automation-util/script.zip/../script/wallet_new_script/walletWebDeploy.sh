#!/bin/bash
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/tomcat_web
echo $tomcatPath
backupPath=/paytm
if [ $1 = automation ]
then
    sshHost=dev@10.144.18.114
    source /paytm/script/wallet_new_script/EnvironmentDetails/automation.sh
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletCommonPomXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebPomXML.sh $2
elif [ $1 = hotfix ]
then
   sshHost=pgtest@10.142.51.92
    source /paytm/script/wallet_new_script/EnvironmentDetails/hotfix.sh
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletCommonPomXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebPomXML.sh $2
elif [ $1 = ite ]
then
   sshHost=pgtest@10.142.52.34
    source /paytm/script/wallet_new_script/EnvironmentDetails/ite.sh
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletCommonPomXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebPomXML.sh $2
elif [ $1 = qa5 ]
then
   sshHost=pgtest@10.142.52.27
    source /paytm/script/wallet_new_script/EnvironmentDetails/qa5.sh
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletCommonPomXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebXML.sh $2
sh /paytm/script/wallet_new_script/configFiles/walletWeb/walletWebPomXML.sh $2
else
    echo Incorrect profile
fi
echo selected server is  $sshHost
WORKSPACE=$2
cd $WORKSPACE/paytm-wallet;
mvn clean install -DskipTests -Ptest92
if [ $? -eq 0 ]; then
    echo "build successful"
else
    echo "build  failed."
   exit 1 
fi
scp $WORKSPACE/paytm-wallet/wallet-web/target/wallet-web-1.0-SNAPSHOT.war $sshHost:/paytm/NewBuild
ssh -T $sshHost  "ps aux | grep 'tomcat_web'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshHost  mv $tomcatPath/webapps/wallet-web  $backupPath/BuildBckup/wallet-web_$CurrentTime
echo "ssh -T" $sshHost  "mv" $tomcatPath"/webapps/wallet-web"  $backupPath"/BuildBckup/wallet-web_"$CurrentTime
ssh -T $sshHost cp  $backupPath/NewBuild/wallet-web-1.0-SNAPSHOT.war $tomcatPath/webapps/wallet-web.war
ssh -T $sshHost sh $tomcatPath/bin/startup.sh
echo "tomcat started"
#sleep 15
#ssh -T $sshHost  "ps aux | grep 'tomcat_web'| grep -v grep|awk '{print \$2}' | xargs kill -9"
#ssh -T $sshHost cp /paytm/BuildBckup/web.xml /paytm/tomcat_web/webapps/wallet-web/WEB-INF/web.xml
#ssh -T $sshHost sh $tomcatPath/bin/startup.sh 
