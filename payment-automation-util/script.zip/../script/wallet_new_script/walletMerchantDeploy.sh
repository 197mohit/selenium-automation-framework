#!/bin/bash
. /paytm/script/commonFunctions.sh

profile=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
tomcatPath=/paytm/tomcat_merchant
backupPath=/paytm

echo "profile: " $profile
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $profile = auto ]
then
    sshHost=dev@10.144.18.113
    source /paytm/script/wallet_new_script/EnvironmentDetails/automation.sh
elif [ $profile = hotfix ]
then
   sshHost=pgtest@10.142.51.121
   source /paytm/script/wallet_new_script/EnvironmentDetails/hotfix.sh
elif [ $profile = staging ]
then
   sshHost=pgtest@10.142.52.80
   source /paytm/script/wallet_new_script/EnvironmentDetails/hotfix.sh
elif [ $profile = ite ]
then
   sshHost=pgtest@10.142.52.38
   source /paytm/script/wallet_new_script/EnvironmentDetails/ite.sh
elif [ $profile = qa5 ]
then
   sshHost=pgtest@10.142.52.41
   source /paytm/script/wallet_new_script/EnvironmentDetails/qa5.sh
else
    echo Incorrect profile
    exit 1
fi

sh /paytm/script/wallet_new_script/configFiles/walletMerchant/walletCommonPomXML.sh $WORKSPACE
validateStep "creating properties"
cd $WORKSPACE; mvn clean install -DskipTests -Ptest92
validateStep "build project"
scp $WORKSPACE/merchant-panel/target/wallet-merchant.war $sshHost:/paytm/NewBuild
validateStep "scp war to NewBuild"
ssh -T $sshHost  "ps aux | grep 'tomcat_merchant'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T $sshHost  mv $tomcatPath/webapps/wallet-merchant  $backupPath/BuildBckup/wallet-merchant_$CurrentTime
validateStep "backup project"
ssh -T $sshHost cp  $backupPath/NewBuild/wallet-merchant.war $tomcatPath/webapps/wallet-merchant.war
validateStep "copy project folder to paytm"
ssh -T $sshHost sh $tomcatPath/bin/startup.sh
echo "tomcat started"
#sleep 15
#ssh -T $sshHost  "ps aux | grep 'tomcat_merchant'| grep -v grep|awk '{print \$2}' | xargs kill -9"
#ssh -T $sshHost "sh /paytm/script/change_log_fileLocation.sh"
#ssh -T $sshHost sh $tomcatPath/bin/startup.sh
      
