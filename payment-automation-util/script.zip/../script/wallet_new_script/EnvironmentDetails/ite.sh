#!/bin/bash

export oldServiceURL="http://10.142.0.109:18080";
export newServiceURL="http://10.142.0.124:18080";
export walletWebURL="http://10.142.52.34:18080";
export redisURL="10.142.52.34";
export merchantURL="http://10.142.52.38:18081";
export walletAdminURL="http://10.142.0.112:18080";
export oldesURL="10.142.52.40:9300";
export esURL="10.142.52.40:9300,10.142.52.40:9200";
export kafkaZookeeperURL="10.142.52.34:2181";
export kafkaBrokerURL="10.142.52.34:9092";
export authURL="https://accounts-staging.paytm.in";
export authAdminPass="paytm@197";
export umpURL="https://wallet-staging.paytm.in";
export logLocation="alog";
export cassandraURL="10.142.52.40";
export mappingURL="https:pgp-ite.paytm.in";
