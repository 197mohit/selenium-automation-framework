#!/bin/bash

export oldServiceURL="http://10.142.0.107:18080";
export newServiceURL="http://10.142.0.122:18080";
export walletWebURL="http://10.144.18.114:18080";
export redisURL="10.144.18.114";
export merchantURL="http://10.144.18.113:18081";
export walletAdminURL="http://10.142.0.112:18080";
export oldesURL="10.142.0.135:9300";
export esURL="10.144.18.113:9300,10.144.18.113:9200";
export kafkaZookeeperURL="10.144.18.114:2181";
export kafkaBrokerURL="10.144.18.114:9092";
export authURL="https://accounts-staging.paytm.in";
export authAdminPass="paytm@197";
export umpURL="https://wallet-staging.paytm.in";
export logLocation="alog";
export cassandraURL="10.144.18.113";
export mappingURL="https://pgp-automation.paytm.in";
