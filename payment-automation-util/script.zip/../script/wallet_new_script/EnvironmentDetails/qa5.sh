#!/bin/bash

export oldServiceURL="http://10.142.0.109:18080";
export newServiceURL="http://10.142.0.124:18080";
export walletWebURL="http://10.142.52.27:18080";
export redisURL="10.142.52.27";
export merchantURL="http://10.142.52.41:18081";
export walletAdminURL="http://10.142.0.112:18080";
export oldesURL="10.142.52.39:9300";
export esURL="10.142.52.39:9300,10.142.52.39:9200";
export kafkaZookeeperURL="10.142.52.27:2181";
export kafkaBrokerURL="10.142.52.27:9092";
export authURL="https://accounts-staging.paytm.in";
export authAdminPass="paytm@197";
export umpURL="https://pgp-qa5.paytm.in";
export logLocation="alog";
export cassandraURL="10.142.52.39";
export mappingURL="https://pgp-qa5.paytm.in"
