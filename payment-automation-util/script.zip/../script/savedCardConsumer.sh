profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
backupPath=/paytm/BuildBckup

echo "profile: " $profileName
echo "backup path: " $backupPath
echo "workspace: " $WORKSPACE

if [ $1 = auto ]
then
    	sshServer=dev@10.144.18.110
elif [ $1 = hotfix ]
then
   	sshServer=pgtest@10.142.51.104
elif [ $1 = staging ]
then
   	sshServer=pgtest@
	echo "server address not provided in script so, terminating script"
	exit 1
elif [ $1 = qa4 ]
then
   	sshServer=pgtest@10.142.52.29
elif [ $1 = qa5 ]
then
   	sshServer=pgtest@10.142.52.26
else
    	echo Incorrect profile
	exit 1
fi

echo "copying resources to server: " $sshServer
scp -r $WORKSPACE/../Build-Resources/pgp_$profileName/savecardservice/project $sshServer:/paytm/NewBuild/

cd $WORKSPACE
mvn clean install  -DskipTests -e

scp -r $WORKSPACE/savedcardConsumer/target/savedcardConsumer $sshServer:/paytm/NewBuild
ssh -T  $sshServer  "ps aux | grep 'looper'| grep -v grep|awk '{print \$2}' | xargs kill -9"
ssh -T  $sshServer mv /paytm/savedcardConsumer  $backupPath/savedcardConsumer_$CurrentTime
if [ $? -eq 0 ]; then
    echo "Old build backup done"
else
    echo "Old build backup fail"
fi
ssh -T $sshServer mv  /paytm/NewBuild/savedcardConsumer /paytm/
if [ $? -eq 0 ]; then
    echo "folder copy to  paytm success"
else
    echo "folder copy to paytm  fail"
fi
ssh -T $sshServer rm -rf /etc/appconf/project_bckup/project
ssh -T $sshServer mv /etc/appconf/project /etc/appconf/project_bckup
ssh -T $sshServer mv /paytm/NewBuild/project /etc/appconf/project
if [ $? -eq 0 ]; then
    echo "appconf folder updated successfully"
else
    echo "appconf folder updated successfully"
fi
nohup ssh -T $sshServer sh /paytm/savedcardConsumer/bin/startserver.sh &
