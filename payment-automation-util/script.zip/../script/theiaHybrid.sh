profileName=$1
CurrentTime=`date +"%m-%d-%Y-%N"`
Module=$3
Theia=$4
if [ $1 = auto ]
then
  if [ $4 = primary ]
  then
      
    theiaSshServer=dev@10.144.18.101
    theiaStaticSshServer=dev@10.144.18.121
    echo $theiaSshServer  
  else
    theiaSshServer=dev@10.144.18.119		
    theiaStaticSshServer=dev@10.144.18.121
    echo $theiaSshServer
  fi

elif [ $1 = hotfix ]
then
  if [ $4 = primary ]
  then 
    theiaSshServer=pgtest@10.142.51.122
    theiaStaticSshServer=pgtest@10.142.51.87
    echo $theiaSshServer 
  else
    theiaSshServer=pgtest@10.142.51.209
    theiaStaticSshServer=pgtest@10.142.51.87
    echo $theiaSshServer
  fi

elif [ $1 = staging ]
then
   profileName=staging
   theiaSshServer=pgtest@10.142.51.135
   theiaStaticSshServer=pgtest@10.142.51.165
   echo $theiaSshServer
elif [ $1 = qa4 ]
then
   theiaSshServer=pgtest@10.142.51.201
   theiaStaticSshServer=pgtest@10.142.51.239
elif [ $1 = qa5 ]
then
   theiaSshServer=pgtest@10.142.51.198
   theiaStaticSshServer=pgtest@10.142.51.236

else
    echo Incorrect profile
    exit 1
fi

echo Select server is  $theiaSshServer
WORKSPACE=$2
cd $WORKSPACE;
echo "theia server:" $theiaSshServer "static server:" $theiaStaticSshServer
mvn clean install  -DskipTests -e
if [ $? -eq 0 ]; then
    echo "Build successful"
else
    echo "Build failed "
    exit 1;
fi

if [ $3 = theia_only ]
then
  echo "running theiaBuildNew script"
  cd /paytm/script/
  sh theiaBuildNew.sh $WORKSPACE $profileName $theiaSshServer
elif [ $3 = theiaStatic_only ]
then
  cd /paytm/script/
  sh theiaStaticNew.sh $WORKSPACE $theiaStaticSshServer
elif [ $3 = theia_plus_theiaStatic ]
then
  cd /paytm/script/
  sh theiaBuildNew.sh $WORKSPACE $profileName $theiaSshServer
  sh theiaStaticNew.sh $WORKSPACE $theiaStaticSshServer
else
  echo Incorrect Module Name
fi

